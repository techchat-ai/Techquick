package com.technology.techquick.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

import com.technology.techquick.device.HudStat

/**
 * One HUD vitals tile, given real depth instead of a flat outline: a
 * drop shadow lifts it off the background, a subtle glass gradient (lighter
 * top edge, darker base) fakes a bevel, and a slight perspective tilt makes
 * the two flanking columns feel like they curve back and away from the
 * central orb rather than sitting on a flat plane.
 */
@Composable
fun HudWidgetCard(stat: HudStat, modifier: Modifier = Modifier, tiltDegrees: Float = 0f) {
    val accent = MaterialTheme.colorScheme.secondary
    Column(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                rotationY = tiltDegrees
                cameraDistance = 24f * density
            }
            .shadow(
                elevation = 6.dp,
                shape = RoundedCornerShape(10.dp),
                ambientColor = accent.copy(alpha = 0.4f),
                spotColor = accent.copy(alpha = 0.6f)
            )
            .background(
                Brush.verticalGradient(
                    listOf(
                        MaterialTheme.colorScheme.surface.copy(alpha = 0.75f),
                        MaterialTheme.colorScheme.surface.copy(alpha = 0.35f)
                    )
                ),
                RoundedCornerShape(10.dp)
            )
            .border(1.dp, accent.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(
            stat.label,
            style = MaterialTheme.typography.labelSmall,
            color = accent.copy(alpha = 0.9f),
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
        Text(
            stat.value,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
