package com.technology.techquick.actions.impl

import android.content.Context
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Build
import com.technology.techquick.model.ActionResult
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DeviceActions(private val context: Context) {

    private val audioManager by lazy { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    private val cameraManager by lazy { context.getSystemService(Context.CAMERA_SERVICE) as CameraManager }

    fun setVolume(percentage: Int): ActionResult {
        val clamped = percentage.coerceIn(0, 100)
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val target = (max * clamped / 100.0).toInt()
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
        return ActionResult.Success("Media volume set to $clamped%.", "$clamped%")
    }

    fun adjustVolume(amountPercent: Int, raise: Boolean): ActionResult {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val step = (max * amountPercent / 100.0).toInt().coerceAtLeast(1)
        val newVal = if (raise) (current + step).coerceAtMost(max) else (current - step).coerceAtLeast(0)
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVal, 0)
        val percent = (newVal * 100.0 / max).toInt()
        return ActionResult.Success(
            if (raise) "Volume increased to $percent%." else "Volume decreased to $percent%.",
            "$percent%"
        )
    }

    fun setFlashlight(on: Boolean): ActionResult {
        return try {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return ActionResult.Failure("This device doesn't have a flashlight.")
            cameraManager.setTorchMode(cameraId, on)
            ActionResult.Success(if (on) "Flashlight turned on." else "Flashlight turned off.", if (on) "ON" else "OFF")
        } catch (e: Exception) {
            ActionResult.Failure("Couldn't control the flashlight: ${e.message}")
        }
    }

    fun getTime(): ActionResult {
        val fmt = SimpleDateFormat("h:mm a", Locale.getDefault())
        return ActionResult.Success("It's ${fmt.format(Date())}.", fmt.format(Date()))
    }

    fun getDate(): ActionResult {
        val fmt = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault())
        return ActionResult.Success("Today is ${fmt.format(Date())}.", fmt.format(Date()))
    }
}
