package com.technology.techquick.device

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.StatFs
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale

/** A single HUD widget's label + value, e.g. ("BATTERY", "91% - Charging"). */
data class HudStat(val label: String, val value: String)

/**
 * Pulls the small "vitals" widgets shown on the HUD home screen straight
 * from the device — no fake/placeholder data. Every function is safe to
 * call even without the relevant permission; it just degrades to a plain
 * "unavailable" string instead of crashing.
 */
object DeviceStatusProvider {

    private fun granted(context: Context, permission: String) =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    fun battery(context: Context): HudStat {
        return try {
            val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            val value = if (pct >= 0) "$pct% ${if (charging) "- Charging" else ""}".trim() else "Unavailable"
            HudStat("BATTERY", value)
        } catch (e: Exception) {
            HudStat("BATTERY", "Unavailable")
        }
    }

    fun connectivity(context: Context): HudStat {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return HudStat("CONNECTIVITY", "Unavailable")
            val network = cm.activeNetwork ?: return HudStat("CONNECTIVITY", "Offline")
            val caps = cm.getNetworkCapabilities(network) ?: return HudStat("CONNECTIVITY", "Offline")
            val label = when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi Connected"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile Data"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                else -> "Connected"
            }
            HudStat("CONNECTIVITY", label)
        } catch (e: Exception) {
            HudStat("CONNECTIVITY", "Unavailable")
        }
    }

    fun systemHealth(context: Context): HudStat {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am.getMemoryInfo(memInfo)
            val ramFreePct = if (memInfo.totalMem > 0) (memInfo.availMem * 100 / memInfo.totalMem).toInt() else 100

            val stat = StatFs(context.filesDir.path)
            val storageFreePct = if (stat.blockCountLong > 0)
                (stat.availableBlocksLong * 100 / stat.blockCountLong).toInt() else 100

            val label = when {
                memInfo.lowMemory -> "Low Memory"
                ramFreePct < 15 || storageFreePct < 5 -> "Attention Needed"
                else -> "Operational"
            }
            HudStat("SYSTEM HEALTH", label)
        } catch (e: Exception) {
            HudStat("SYSTEM HEALTH", "Unavailable")
        }
    }

    /** Reverse-geocodes the last known coarse location into "City, Region". Requires location permission. */
    suspend fun location(context: Context): HudStat = withContext(Dispatchers.IO) {
        if (!granted(context, Manifest.permission.ACCESS_COARSE_LOCATION) &&
            !granted(context, Manifest.permission.ACCESS_FINE_LOCATION)
        ) {
            return@withContext HudStat("LOCATION", "Permission needed")
        }
        try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val loc = lm.getProviders(true)
                .mapNotNull { provider -> lm.getLastKnownLocation(provider) }
                .maxByOrNull { it.time }
                ?: return@withContext HudStat("LOCATION", "Finding...")

            @Suppress("DEPRECATION")
            val addresses = Geocoder(context, Locale.getDefault())
                .getFromLocation(loc.latitude, loc.longitude, 1)
            val place = addresses?.firstOrNull()
            val city = place?.locality ?: place?.subAdminArea
            val region = place?.adminArea
            val label = listOfNotNull(city, region).joinToString(", ").ifBlank { "Unknown" }
            HudStat("LOCATION", label)
        } catch (e: Exception) {
            HudStat("LOCATION", "Unavailable")
        }
    }

    fun lastKnownLatLon(context: Context): Pair<Double, Double>? {
        if (!granted(context, Manifest.permission.ACCESS_COARSE_LOCATION) &&
            !granted(context, Manifest.permission.ACCESS_FINE_LOCATION)
        ) return null
        return try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val loc = lm.getProviders(true)
                .mapNotNull { provider -> lm.getLastKnownLocation(provider) }
                .maxByOrNull { it.time } ?: return null
            loc.latitude to loc.longitude
        } catch (e: Exception) {
            null
        }
    }

    /** Title + start time of the next upcoming calendar event, across all calendars on-device. */
    suspend fun nextCalendarEvent(context: Context): HudStat = withContext(Dispatchers.IO) {
        if (!granted(context, Manifest.permission.READ_CALENDAR)) {
            return@withContext HudStat("CALENDAR", "Permission needed")
        }
        try {
            val now = System.currentTimeMillis()
            val end = now + 1000L * 60 * 60 * 24 * 14 // look 2 weeks ahead
            val uri = CalendarContract.Instances.CONTENT_URI.buildUpon()
                .appendPath(now.toString())
                .appendPath(end.toString())
                .build()
            val projection = arrayOf(
                CalendarContract.Instances.TITLE,
                CalendarContract.Instances.BEGIN
            )
            context.contentResolver.query(uri, projection, null, null, "${CalendarContract.Instances.BEGIN} ASC")
                ?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val title = cursor.getString(0) ?: "Untitled event"
                        val begin = cursor.getLong(1)
                        val time = SimpleDateFormat("h:mm a", Locale.getDefault()).format(begin)
                        return@withContext HudStat("CALENDAR", "$title @ $time")
                    }
                }
            HudStat("CALENDAR", "No upcoming events")
        } catch (e: Exception) {
            HudStat("CALENDAR", "Unavailable")
        }
    }
}
