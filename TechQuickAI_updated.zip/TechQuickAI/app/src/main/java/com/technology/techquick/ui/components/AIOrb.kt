package com.technology.techquick.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp

enum class OrbState { IDLE, LISTENING, THINKING, EXECUTING, FINISHED }

/**
 * TechQuick's visual identity: a soft glowing gradient orb that animates
 * differently for each assistant state. Pure Compose animation, no image
 * assets needed, so it always renders crisply at any size.
 */
@Composable
fun AIOrb(state: OrbState, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 180.dp) {
    val infinite = rememberInfiniteTransition(label = "orb")

    val idlePulse by infinite.animateFloat(
        initialValue = 0.94f, targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(2200), RepeatMode.Reverse), label = "idlePulse"
    )
    val listeningPulse by infinite.animateFloat(
        initialValue = 0.98f, targetValue = 1.16f,
        animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "listenPulse"
    )
    val rotation by infinite.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(2600, easing = androidx.compose.animation.core.LinearEasing)), label = "rotation"
    )

    val scale = when (state) {
        OrbState.IDLE -> idlePulse
        OrbState.LISTENING -> listeningPulse
        OrbState.THINKING -> 1.05f
        OrbState.EXECUTING -> 1.02f
        OrbState.FINISHED -> 1f
    }

    val colors = MaterialTheme.colorScheme
    val gradient = Brush.radialGradient(
        colors = listOf(colors.secondary, colors.primary, colors.tertiary),
        center = Offset(0.35f, 0.3f)
    )

    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        // Outer glow
        Box(
            modifier = Modifier
                .size(size)
                .scale(scale * 1.15f)
                .blur(28.dp)
                .background(gradient, CircleShape)
        )
        // Core orb
        Box(
            modifier = Modifier
                .size(size * 0.72f)
                .graphicsLayer {
                    scaleX = scale; scaleY = scale
                    if (state == OrbState.THINKING) rotationZ = rotation
                }
                .background(gradient, CircleShape)
        )
        // Inner highlight for depth
        Box(
            modifier = Modifier
                .size(size * 0.3f)
                .scale(scale)
                .background(colors.surface.copy(alpha = 0.18f), CircleShape)
        )
    }
}
