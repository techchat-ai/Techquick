package com.technology.techquick.data

import android.content.Context
import com.technology.techquick.model.ChatMessage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Keeps the current conversation in memory for the session. Kept as its own
 * repository (rather than baked into the ViewModel) so a future version can
 * swap in Room-backed persistence without touching the UI layer.
 */
class ConversationRepository(private val context: Context) {

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages

    fun add(message: ChatMessage) {
        _messages.value = _messages.value + message
    }

    fun updateLast(transform: (ChatMessage) -> ChatMessage) {
        val list = _messages.value
        if (list.isEmpty()) return
        _messages.value = list.dropLast(1) + transform(list.last())
    }

    fun replace(id: String, transform: (ChatMessage) -> ChatMessage) {
        _messages.value = _messages.value.map { if (it.id == id) transform(it) else it }
    }

    fun clear() {
        _messages.value = emptyList()
    }

    /** Conversation history formatted for AIBrain: (isUser, text) oldest-first. */
    fun historyForAI(): List<Pair<Boolean, String>> =
        _messages.value.map { (it.sender == com.technology.techquick.model.Sender.USER) to it.text }
}
