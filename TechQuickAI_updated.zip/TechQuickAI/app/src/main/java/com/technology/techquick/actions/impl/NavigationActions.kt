package com.technology.techquick.actions.impl

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.technology.techquick.model.ActionResult
import java.net.URLEncoder

class NavigationActions(private val context: Context) {

    fun openMaps(): ActionResult = try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        ActionResult.Success("Opening Google Maps.")
    } catch (e: Exception) {
        ActionResult.Failure("Couldn't open Maps.")
    }

    fun searchMaps(query: String): ActionResult {
        if (query.isBlank()) return ActionResult.Failure("What location should I search for?")
        val encoded = URLEncoder.encode(query, "UTF-8")
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$encoded")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            ActionResult.Success("Searching Maps for \"$query\".", query)
        } catch (e: Exception) {
            ActionResult.Failure("Couldn't search Maps for that.")
        }
    }
}
