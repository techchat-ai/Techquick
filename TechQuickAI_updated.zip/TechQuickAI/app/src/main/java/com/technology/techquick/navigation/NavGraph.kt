package com.technology.techquick.navigation

object Routes {
    const val WELCOME = "welcome"
    const val CONNECT_AI = "connect_ai"
    const val HOME = "home"
    const val SETTINGS = "settings"
}
