package com.technology.techquick.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.technology.techquick.data.AppTheme
import com.technology.techquick.viewmodel.SettingsViewModel

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 20.dp, bottom = 8.dp))
}

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onBack: () -> Unit,
    onChangeApiKey: () -> Unit
) {
    val state by viewModel.state.collectAsState()
    var showRemoveDialog by remember { mutableStateOf(false) }
    var showClearHistoryDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 12.dp)) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
            Text("Settings", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        SectionTitle("AI Brain")
        Text("Current provider: ${state.providerName}", style = MaterialTheme.typography.bodyLarge)
        Text(
            if (state.hasApiKey) "API key status: Connected" else "API key status: Not connected",
            color = if (state.hasApiKey) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onChangeApiKey) { Text("Change API Key") }
            OutlinedButton(onClick = { showRemoveDialog = true }, enabled = state.hasApiKey) { Text("Remove API Key") }
        }

        Divider(Modifier.padding(top = 20.dp))

        SectionTitle("Assistant")
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Voice responses")
            Switch(checked = state.voiceResponsesEnabled, onCheckedChange = viewModel::setVoiceResponses)
        }
        Spacer(Modifier.height(10.dp))
        Text("Response style", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            com.technology.techquick.data.ResponseStyle.entries.forEach { style ->
                FilterChip(
                    selected = state.responseStyle == style,
                    onClick = { viewModel.setResponseStyle(style) },
                    label = { Text(style.name.lowercase().replaceFirstChar { it.uppercase() }) }
                )
            }
        }

        Divider(Modifier.padding(top = 20.dp))

        SectionTitle("Appearance")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AppTheme.entries.forEach { theme ->
                FilterChip(
                    selected = state.theme == theme,
                    onClick = { viewModel.setTheme(theme) },
                    label = { Text(theme.name.lowercase().replaceFirstChar { it.uppercase() }) }
                )
            }
        }

        Divider(Modifier.padding(top = 20.dp))

        SectionTitle("Privacy")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { showClearHistoryDialog = true }) { Text("Clear conversation history") }
        }

        Divider(Modifier.padding(top = 20.dp))

        SectionTitle("About")
        Text("TechQuick AI", style = MaterialTheme.typography.bodyLarge)
        Text("Version 1.0", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        Spacer(Modifier.height(32.dp))
    }

    if (showRemoveDialog) {
        AlertDialog(
            onDismissRequest = { showRemoveDialog = false },
            title = { Text("Remove API key?") },
            text = { Text("TechQuick won't be able to understand commands until you connect an AI brain again.") },
            confirmButton = {
                Button(onClick = { viewModel.removeApiKey(); showRemoveDialog = false }) { Text("Remove") }
            },
            dismissButton = {
                OutlinedButton(onClick = { showRemoveDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showClearHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showClearHistoryDialog = false },
            title = { Text("Clear conversation history?") },
            text = { Text("This removes all messages from this session. This can't be undone.") },
            confirmButton = {
                Button(onClick = { viewModel.clearConversationHistory(); showClearHistoryDialog = false }) { Text("Clear") }
            },
            dismissButton = {
                OutlinedButton(onClick = { showClearHistoryDialog = false }) { Text("Cancel") }
            }
        )
    }
}
