package com.technology.techquick.ai

/**
 * Common contract every AI provider implements. AIBrain talks only to this
 * interface, so adding a new provider means writing one small class and
 * registering it in AIProviderFactory — nothing else in the app changes.
 */
interface AIProvider {

    /**
     * Sends the conversation to the model and returns its raw text reply.
     * TechQuick's system prompt instructs the model to reply with JSON only,
     * so the raw text returned here is expected to be parseable by AIBrain.
     *
     * @param systemPrompt Instructions + action catalog + personality rules.
     * @param history Prior turns as (isUser, text) pairs, oldest first.
     * @param userMessage The newest user message to respond to.
     * @param apiKey The user's own API key, read from secure storage.
     * @param baseUrl Provider endpoint (used by OPENAI_COMPATIBLE providers).
     * @param model Model name to request.
     */
    suspend fun sendMessage(
        systemPrompt: String,
        history: List<Pair<Boolean, String>>,
        userMessage: String,
        apiKey: String,
        baseUrl: String,
        model: String
    ): Result<String>

    /** Lightweight call used by the "Test Connection" button during onboarding. */
    suspend fun testConnection(apiKey: String, baseUrl: String, model: String): Result<Unit>
}
