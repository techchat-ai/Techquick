package com.technology.techquick.model

import kotlinx.serialization.Serializable

/**
 * The strict JSON contract the AI brain must return. Nothing outside this
 * shape is ever executed — see ActionRegistry / ActionEngine.
 */
@Serializable
data class AIActionResponse(
    val response: String = "",
    val actions: List<AIAction> = emptyList(),
    val needsClarification: Boolean = false
)

@Serializable
data class AIAction(
    val type: String,
    val parameters: Map<String, String> = emptyMap()
)

/** Describes one entry in the Action Registry so it can be advertised to the AI brain. */
data class ActionDefinition(
    val type: String,
    val description: String,
    val parameters: List<String>,
    val isSensitive: Boolean
)

sealed class ActionResult {
    data class Success(val summary: String, val detail: String? = null) : ActionResult()
    data class Failure(val reason: String) : ActionResult()
}
