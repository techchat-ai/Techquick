package com.technology.techquick.actions.impl

import android.content.Context
import android.content.Intent
import com.technology.techquick.model.ActionResult

class AppActions(private val context: Context) {

    fun openApp(appName: String): ActionResult {
        if (appName.isBlank()) return ActionResult.Failure("I need an app name to open.")
        val pm = context.packageManager

        // Query only apps that actually expose a launcher entry point. This
        // respects Android 11+ package-visibility rules (see the <queries>
        // block in the manifest) instead of getInstalledApplications(),
        // which returns an empty/filtered list on modern devices without
        // QUERY_ALL_PACKAGES.
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val candidates = pm.queryIntentActivities(launcherIntent, 0)

        val exact = candidates.firstOrNull {
            it.loadLabel(pm).toString().equals(appName, ignoreCase = true)
        }
        val partial = exact ?: candidates.firstOrNull {
            it.loadLabel(pm).toString().contains(appName, ignoreCase = true)
        }
        val match = partial
            ?: return ActionResult.Failure("I couldn't find an app called '$appName' on this device.")

        val packageName = match.activityInfo.packageName
        val launchIntent = pm.getLaunchIntentForPackage(packageName)
            ?: return ActionResult.Failure("'$appName' can't be launched directly.")

        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        val label = match.loadLabel(pm).toString()
        return ActionResult.Success("Opening $label.", label)
    }
}
