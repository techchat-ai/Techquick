package com.technology.techquick.actions

import android.content.Context
import com.technology.techquick.actions.impl.AppActions
import com.technology.techquick.actions.impl.CommunicationActions
import com.technology.techquick.actions.impl.DeviceActions
import com.technology.techquick.actions.impl.NavigationActions
import com.technology.techquick.actions.impl.SearchActions
import com.technology.techquick.actions.impl.UtilityActions
import com.technology.techquick.model.AIAction
import com.technology.techquick.model.ActionResult

/**
 * Executes a validated AIAction against real Android APIs.
 *
 * This is the ONLY place that touches Android system capabilities on
 * behalf of the AI. The AI brain never runs code directly — it only ever
 * returns action type + parameters, which are validated against
 * ActionRegistry before reaching here.
 */
class ActionEngine(
    private val context: Context,
    private val registry: ActionRegistry
) {
    private val deviceActions = DeviceActions(context)
    private val appActions = AppActions(context)
    private val searchActions = SearchActions(context)
    private val navigationActions = NavigationActions(context)
    private val communicationActions = CommunicationActions(context)
    private val utilityActions = UtilityActions(context)

    /**
     * Runs one action. Returns Failure for unknown/unregistered types instead
     * of throwing, so the caller can always show the user something sane.
     */
    suspend fun execute(action: AIAction): ActionResult {
        if (!registry.isRegistered(action.type)) {
            return ActionResult.Failure("TechQuick doesn't know how to do '${action.type}'.")
        }

        return try {
            when (action.type) {
                "set_volume" -> deviceActions.setVolume(action.parameters["percentage"]?.toIntOrNull() ?: 50)
                "increase_volume" -> deviceActions.adjustVolume(action.parameters["amount"]?.toIntOrNull() ?: 10, raise = true)
                "decrease_volume" -> deviceActions.adjustVolume(action.parameters["amount"]?.toIntOrNull() ?: 10, raise = false)
                "flashlight_on" -> deviceActions.setFlashlight(true)
                "flashlight_off" -> deviceActions.setFlashlight(false)
                "get_time" -> deviceActions.getTime()
                "get_date" -> deviceActions.getDate()

                "open_app" -> appActions.openApp(action.parameters["app_name"].orEmpty())

                "web_search" -> searchActions.webSearch(action.parameters["query"].orEmpty())
                "youtube_search" -> searchActions.youtubeSearch(action.parameters["query"].orEmpty())
                "play_store_search" -> searchActions.playStoreSearch(action.parameters["query"].orEmpty())

                "maps_open" -> navigationActions.openMaps()
                "maps_search" -> navigationActions.searchMaps(action.parameters["query"].orEmpty())

                "whatsapp_open" -> communicationActions.openWhatsApp()
                "whatsapp_message" -> communicationActions.sendWhatsAppMessage(
                    action.parameters["contact_name"].orEmpty(),
                    action.parameters["message"].orEmpty()
                )
                "open_dialer" -> communicationActions.openDialer(action.parameters["phone_number"].orEmpty())
                "call_contact" -> communicationActions.callContact(action.parameters["contact_name_or_number"].orEmpty())

                "calculator" -> utilityActions.openCalculator()
                "open_settings" -> utilityActions.openSettings()
                "open_camera" -> utilityActions.openCamera()
                "open_gallery" -> utilityActions.openGallery()

                else -> ActionResult.Failure("Android doesn't allow me to perform that action directly.")
            }
        } catch (e: SecurityException) {
            ActionResult.Failure("I need a permission I don't have yet for that action.")
        } catch (e: Exception) {
            ActionResult.Failure(e.message ?: "Something went wrong performing that action.")
        }
    }
}
