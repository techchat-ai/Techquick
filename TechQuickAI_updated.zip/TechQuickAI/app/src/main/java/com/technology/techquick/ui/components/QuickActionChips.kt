package com.technology.techquick.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AssistChip
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class QuickAction(val emoji: String, val label: String, val prompt: String)

val DEFAULT_QUICK_ACTIONS = listOf(
    QuickAction("\uD83D\uDD26", "Torch", "Turn on the torch"),
    QuickAction("\uD83D\uDD0A", "Volume", "Set volume to 50%"),
    QuickAction("\u25B6", "YouTube", "Search YouTube for "),
    QuickAction("\uD83D\uDD0E", "Search", "Search the web for "),
    QuickAction("\uD83D\uDCF1", "Apps", "Open "),
    QuickAction("\uD83D\uDDFA", "Maps", "Open Google Maps"),
)

@Composable
fun QuickActionChips(onActionSelected: (QuickAction) -> Unit, modifier: Modifier = Modifier) {
    LazyRow(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)
    ) {
        items(DEFAULT_QUICK_ACTIONS) { action ->
            AssistChip(
                onClick = { onActionSelected(action) },
                label = { androidx.compose.material3.Text("${action.emoji} ${action.label}") }
            )
        }
    }
}
