package com.technology.techquick.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Wraps Android's EncryptedSharedPreferences (backed by the Android
 * Keystore) so API keys are never stored, logged, or hard-coded in plain
 * text anywhere in the app.
 */
class SecureStorage(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "techquick_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveApiKey(key: String) = prefs.edit().putString(KEY_API_KEY, key).apply()
    fun getApiKey(): String? = prefs.getString(KEY_API_KEY, null)
    fun clearApiKey() = prefs.edit().remove(KEY_API_KEY).apply()

    fun saveProvider(providerName: String) = prefs.edit().putString(KEY_PROVIDER, providerName).apply()
    fun getProvider(): String? = prefs.getString(KEY_PROVIDER, null)

    fun saveBaseUrl(url: String) = prefs.edit().putString(KEY_BASE_URL, url).apply()
    fun getBaseUrl(): String? = prefs.getString(KEY_BASE_URL, null)

    fun saveModel(model: String) = prefs.edit().putString(KEY_MODEL, model).apply()
    fun getModel(): String? = prefs.getString(KEY_MODEL, null)

    fun clearAll() = prefs.edit().clear().apply()

    fun hasValidConfig(): Boolean = !getApiKey().isNullOrBlank() && !getProvider().isNullOrBlank()

    private companion object {
        const val KEY_API_KEY = "api_key"
        const val KEY_PROVIDER = "provider"
        const val KEY_BASE_URL = "base_url"
        const val KEY_MODEL = "model"
    }
}
