package com.technology.techquick.ui.theme

import androidx.compose.ui.graphics.Color

// TechQuick brand palette: blue + cyan core, subtle purple accents.
val TQBlue = Color(0xFF3E7BFA)
val TQBluePale = Color(0xFFDCE8FF)
val TQCyan = Color(0xFF22D3EE)
val TQPurple = Color(0xFF8B5CF6)

val TQLightBackground = Color(0xFFF7F9FC)
val TQLightSurface = Color(0xFFFFFFFF)
val TQLightOnSurface = Color(0xFF15181F)
val TQLightOnSurfaceMuted = Color(0xFF6B7280)

val TQDarkBackground = Color(0xFF0B0E14)
val TQDarkSurface = Color(0xFF141821)
val TQDarkOnSurface = Color(0xFFEAEFFB)
val TQDarkOnSurfaceMuted = Color(0xFF9AA4B8)

val TQSuccess = Color(0xFF22C55E)
val TQError = Color(0xFFEF4444)
