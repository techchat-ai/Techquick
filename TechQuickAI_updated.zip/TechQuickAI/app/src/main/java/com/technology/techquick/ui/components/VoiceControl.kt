package com.technology.techquick.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.technology.techquick.ui.theme.HudCyan
import com.technology.techquick.ui.theme.HudCyanBright
import com.technology.techquick.ui.theme.HudCyanDim
import com.technology.techquick.ui.theme.HudPanelFill
import com.technology.techquick.ui.theme.HudTextBright
import com.technology.techquick.ui.theme.HudTextMuted

/**
 * The HUD "voice deck": two waveform clusters flanking the central mic
 * button, with "SPEAK TO TECHQUICK" curved around its ring — mirrors the
 * reference design's voice-input layout. Everything shares one pulse clock
 * so the bars and the ring glow breathe in sync instead of drifting apart.
 */
@Composable
fun VoiceControl(
    isListening: Boolean,
    onTap: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infinite = rememberInfiniteTransition(label = "voiceDeck")
    val amp by infinite.animateFloat(
        initialValue = 0.7f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            tween(if (isListening) 360 else 1500, easing = LinearEasing),
            RepeatMode.Reverse
        ),
        label = "waveAmp"
    )
    val ringGlow by infinite.animateFloat(
        initialValue = if (isListening) 0.6f else 0.35f,
        targetValue = if (isListening) 1f else 0.55f,
        animationSpec = infiniteRepeatable(
            tween(if (isListening) 500 else 2200, easing = LinearEasing),
            RepeatMode.Reverse
        ),
        label = "ringGlow"
    )

    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            WaveformCluster(active = isListening, amp = amp, ascendingTowardEnd = true)

            Box(modifier = Modifier.size(88.dp), contentAlignment = Alignment.Center) {
                // Ambient glow behind the whole control
                Box(
                    Modifier
                        .size(80.dp)
                        .blur(20.dp)
                        .background(
                            Brush.radialGradient(listOf(HudCyan.copy(alpha = ringGlow * 0.55f), Color.Transparent)),
                            CircleShape
                        )
                )
                // Curved inscription sitting in the ring between the glow and the button
                CircularLabel(
                    text = "SPEAK TO TECHQUICK",
                    diameter = 80.dp,
                    color = HudCyanDim.copy(alpha = 0.95f)
                )
                // The actual tappable button
                Surface(
                    onClick = onTap,
                    shape = CircleShape,
                    color = HudPanelFill.copy(alpha = 0.75f),
                    border = BorderStroke(1.6.dp, HudCyan.copy(alpha = ringGlow)),
                    modifier = Modifier
                        .size(58.dp)
                        .shadow(
                            elevation = 16.dp,
                            shape = CircleShape,
                            ambientColor = HudCyan.copy(alpha = 0.55f),
                            spotColor = HudCyanBright.copy(alpha = 0.7f)
                        )
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Filled.Mic,
                            contentDescription = "Speak to TechQuick",
                            tint = HudTextBright,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }

            WaveformCluster(active = isListening, amp = amp, ascendingTowardEnd = false)
        }
        Spacer(Modifier.height(8.dp))
        Text(
            if (isListening) "Voice Input Active" else "Speak to TechQuick",
            style = MaterialTheme.typography.labelMedium,
            color = HudTextMuted
        )
    }
}

/** One flank of bars, tallest nearest the mic and tapering outward. */
@Composable
private fun WaveformCluster(
    active: Boolean,
    amp: Float,
    ascendingTowardEnd: Boolean,
    barCount: Int = 5
) {
    val base = List(barCount) { i -> 5 + i * 5 }
    val heights = if (ascendingTowardEnd) base else base.reversed()
    Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom) {
        heights.forEach { h ->
            val targetHeight = if (active) h * amp else h * 0.35f
            Box(
                Modifier
                    .width(3.dp)
                    .height(targetHeight.dp.coerceAtLeast(3.dp))
                    .background(HudCyan.copy(alpha = if (active) 0.95f else 0.3f), RoundedCornerShape(2.dp))
            )
        }
    }
}
