package com.technology.techquick.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.technology.techquick.TechQuickApplication
import com.technology.techquick.model.AIProviderType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

enum class ConnectionTestState { IDLE, TESTING, SUCCESS, FAILURE }

data class OnboardingUiState(
    val provider: AIProviderType = AIProviderType.GEMINI,
    val apiKey: String = "",
    val baseUrl: String = AIProviderType.GEMINI.defaultBaseUrl,
    val model: String = AIProviderType.GEMINI.defaultModel,
    val testState: ConnectionTestState = ConnectionTestState.IDLE,
    val testError: String? = null
)

class OnboardingViewModel(private val app: TechQuickApplication) : ViewModel() {

    private val _state = MutableStateFlow(OnboardingUiState())
    val state: StateFlow<OnboardingUiState> = _state

    fun onProviderSelected(type: AIProviderType) {
        _state.value = _state.value.copy(
            provider = type,
            baseUrl = type.defaultBaseUrl,
            model = type.defaultModel,
            testState = ConnectionTestState.IDLE
        )
    }

    fun onApiKeyChanged(key: String) {
        _state.value = _state.value.copy(apiKey = key, testState = ConnectionTestState.IDLE)
    }

    fun onBaseUrlChanged(url: String) {
        _state.value = _state.value.copy(baseUrl = url, testState = ConnectionTestState.IDLE)
    }

    fun onModelChanged(model: String) {
        _state.value = _state.value.copy(model = model, testState = ConnectionTestState.IDLE)
    }

    fun testConnection() {
        val s = _state.value
        if (s.apiKey.isBlank()) {
            _state.value = s.copy(testState = ConnectionTestState.FAILURE, testError = "Enter an API key first.")
            return
        }
        _state.value = s.copy(testState = ConnectionTestState.TESTING)
        viewModelScope.launch {
            val result = app.aiBrain.testConnection(s.provider.name, s.apiKey, s.baseUrl, s.model)
            _state.value = if (result.isSuccess) {
                _state.value.copy(testState = ConnectionTestState.SUCCESS, testError = null)
            } else {
                _state.value.copy(
                    testState = ConnectionTestState.FAILURE,
                    testError = "We couldn't connect using this API key. Check the key and try again."
                )
            }
        }
    }

    fun saveAndContinue() {
        val s = _state.value
        app.settingsRepository.saveAIConfig(s.provider, s.apiKey, s.baseUrl, s.model)
    }

    companion object {
        fun factory(app: TechQuickApplication) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = OnboardingViewModel(app) as T
        }
    }
}
