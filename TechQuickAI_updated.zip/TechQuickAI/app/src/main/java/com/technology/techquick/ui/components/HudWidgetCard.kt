package com.technology.techquick.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.technology.techquick.device.HudStat
import com.technology.techquick.ui.theme.HudCyan
import com.technology.techquick.ui.theme.HudCyanDim
import com.technology.techquick.ui.theme.HudPanelFill
import com.technology.techquick.ui.theme.HudTextBright

/**
 * One HUD vitals chip: a flat, thin-bordered rectangle with a small
 * uppercase label and a brighter value line, matching the reference HUD's
 * compact side tags exactly (no 3D tilt or drop shadow — those read as
 * "app card," not "console readout"). Fixed HUD palette, not MaterialTheme.
 */
@Composable
fun HudWidgetCard(stat: HudStat, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(HudPanelFill.copy(alpha = 0.55f), RoundedCornerShape(7.dp))
            .border(1.dp, HudCyan.copy(alpha = 0.45f), RoundedCornerShape(7.dp))
            .padding(horizontal = 9.dp, vertical = 6.dp)
    ) {
        Text(
            stat.label,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            fontSize = 9.sp,
            letterSpacing = 1.sp,
            color = HudCyanDim,
            maxLines = 1
        )
        Text(
            stat.value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.SemiBold,
            color = HudTextBright,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
