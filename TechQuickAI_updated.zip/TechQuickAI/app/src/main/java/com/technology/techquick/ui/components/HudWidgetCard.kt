package com.technology.techquick.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.technology.techquick.device.HudStat

/**
 * One HUD vitals tile: a small glass panel with a cyan hairline border, a
 * tiny uppercase label, and the live value beneath it. Deliberately plain —
 * the orb and response area carry the visual weight, these just report data.
 */
@Composable
fun HudWidgetCard(stat: HudStat, modifier: Modifier = Modifier) {
    val accent = MaterialTheme.colorScheme.secondary
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.55f), RoundedCornerShape(10.dp))
            .border(1.dp, accent.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(
            stat.label,
            style = MaterialTheme.typography.labelSmall,
            color = accent.copy(alpha = 0.85f),
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
        Text(
            stat.value,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
