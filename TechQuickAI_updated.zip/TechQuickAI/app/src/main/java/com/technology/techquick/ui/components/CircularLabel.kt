package com.technology.techquick.ui.components

import android.graphics.PathMeasure
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import android.graphics.Paint as AndroidPaint
import kotlin.math.min

/**
 * A small uppercase label curved along the top of a circle, like an
 * inscription on a coin. Used to wrap "SPEAK TO TECHQUICK" around the
 * voice button's ring, matching the reference HUD's mic control.
 */
@Composable
fun CircularLabel(
    text: String,
    diameter: Dp,
    color: Color,
    modifier: Modifier = Modifier,
    fontSizeSp: Float = 8.5f,
    letterSpacingEm: Float = 0.24f
) {
    Canvas(modifier = modifier.size(diameter)) {
        val radius = min(size.width, size.height) / 2f
        val cx = size.width / 2f
        val cy = size.height / 2f

        // Top semicircle traced left -> right through 12 o'clock (Android's
        // arc angles start at 3 o'clock and increase clockwise), so the
        // text reads normally instead of upside down.
        val path = Path().apply {
            addArc(Rect(cx - radius, cy - radius, cx + radius, cy + radius), 180f, 180f)
        }
        val androidPath = path.asAndroidPath()
        val pathLength = PathMeasure(androidPath, false).length

        val paint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
            this.color = color.toArgb()
            textSize = fontSizeSp.sp.toPx()
            letterSpacing = letterSpacingEm
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textAlign = AndroidPaint.Align.LEFT
        }
        val textWidth = paint.measureText(text)
        val hOffset = ((pathLength - textWidth) / 2f).coerceAtLeast(0f)
        val vOffset = fontSizeSp.sp.toPx() * 0.32f // nudge baseline inward onto the ring

        drawContext.canvas.nativeCanvas.drawTextOnPath(text, androidPath, hOffset, vOffset, paint)
    }
}
