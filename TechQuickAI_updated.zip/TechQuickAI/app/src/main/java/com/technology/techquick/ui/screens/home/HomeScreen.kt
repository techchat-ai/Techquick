package com.technology.techquick.ui.screens.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.technology.techquick.ui.components.AIOrb
import com.technology.techquick.ui.components.InputBar
import com.technology.techquick.ui.components.MessageBubble
import com.technology.techquick.ui.components.QuickActionChips
import com.technology.techquick.viewmodel.HomeViewModel
import java.util.Calendar

private fun greeting(): String {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        hour < 12 -> "Good morning \uD83D\uDC4B"
        hour < 17 -> "Good afternoon \uD83D\uDC4B"
        else -> "Good evening \uD83D\uDC4B"
    }
}

private fun orbStatusText(state: com.technology.techquick.ui.components.OrbState): String = when (state) {
    com.technology.techquick.ui.components.OrbState.IDLE -> "Tap to talk"
    com.technology.techquick.ui.components.OrbState.LISTENING -> "Listening..."
    com.technology.techquick.ui.components.OrbState.THINKING -> "Thinking..."
    com.technology.techquick.ui.components.OrbState.EXECUTING -> "Working on it..."
    com.technology.techquick.ui.components.OrbState.FINISHED -> "Done."
}

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onOpenSettings: () -> Unit,
    onNeedsApiKey: () -> Unit
) {
    val state by viewModel.state.collectAsState()

    LaunchedEffect(state.hasApiKey) {
        if (!state.hasApiKey) onNeedsApiKey()
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Top bar
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("\u26A1", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.width(8.dp))
                Text("TechQuick AI", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Filled.Settings, contentDescription = "Settings")
            }
        }

        state.errorBanner?.let { error ->
            Surface(color = MaterialTheme.colorScheme.errorContainer, modifier = Modifier.fillMaxWidth()) {
                Text(error, modifier = Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onErrorContainer)
            }
        }

        if (state.messages.isEmpty()) {
            // Empty state: greeting + big orb + suggestions
            Column(
                modifier = Modifier.fillMaxWidth().weight(1f).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(greeting(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text("What can I do for you?", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                Spacer(Modifier.height(28.dp))
                Box(
                    modifier = Modifier.height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    AIOrb(state = state.orbState)
                }
                Spacer(Modifier.height(12.dp))
                Text(orbStatusText(state.orbState), style = MaterialTheme.typography.bodyMedium)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 12.dp)
            ) {
                items(state.messages, key = { it.id }) { message ->
                    MessageBubble(
                        message = message,
                        onConfirm = {
                            message.pendingConfirmation?.let {
                                viewModel.confirmAction(message.id, it.actionType, it.parameters)
                            }
                        },
                        onCancel = { viewModel.cancelAction(message.id) }
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                AIOrb(state = state.orbState, size = 56.dp)
            }
        }

        QuickActionChips(
            onActionSelected = { action -> viewModel.onQuickAction(action.prompt, autoSend = !action.prompt.endsWith(" ") ) },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        )

        InputBar(
            text = state.inputText,
            onTextChange = viewModel::onInputChange,
            onSend = { viewModel.sendMessage() },
            onMicClick = { viewModel.startListening() },
            isListening = state.isListening,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)
        )
    }
}
