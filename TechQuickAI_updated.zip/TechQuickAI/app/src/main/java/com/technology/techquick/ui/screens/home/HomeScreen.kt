package com.technology.techquick.ui.screens.home

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.technology.techquick.model.ChatMessage
import com.technology.techquick.ui.components.AIOrb
import com.technology.techquick.ui.components.ActionCardView
import com.technology.techquick.ui.components.HudBackground
import com.technology.techquick.ui.components.HudWidgetCard
import com.technology.techquick.ui.components.InputBar
import com.technology.techquick.ui.components.OrbState
import com.technology.techquick.viewmodel.HomeViewModel
import java.util.Calendar
import java.text.SimpleDateFormat
import java.util.Locale

private fun timeGreeting(): Pair<String, Boolean> {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        hour < 12 -> "GOOD MORNING, SIR" to true
        hour < 17 -> "GOOD AFTERNOON, SIR" to true
        else -> "GOOD EVENING, SIR" to false
    }
}

private fun orbLabel(state: OrbState): String = when (state) {
    OrbState.IDLE -> "ACTIVE"
    OrbState.LISTENING -> "LISTENING"
    OrbState.THINKING -> "THINKING"
    OrbState.EXECUTING -> "WORKING"
    OrbState.FINISHED -> "ACTIVE"
}

/**
 * The TechQuick HUD home screen. This is deliberately NOT a chat transcript:
 * only the single latest turn (the user's query, then TechQuick's reply) is
 * ever on screen at once, each replacing the last with a quick cross-fade —
 * exactly one thing being said at a time, like a HUD readout rather than a
 * scrollback log. Full history still flows to the AI for context; it's just
 * never rendered as a list.
 */
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onOpenSettings: () -> Unit,
    onNeedsApiKey: () -> Unit
) {
    val state by viewModel.state.collectAsState()

    LaunchedEffect(state.hasApiKey) {
        if (!state.hasApiKey) onNeedsApiKey()
    }

    val (greeting, isDay) = timeGreeting()
    val timeLabel = rememberNowLabel()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(MaterialTheme.colorScheme.background, MaterialTheme.colorScheme.surface)
                )
            )
    ) {
        HudBackground(modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 18.dp, vertical = 14.dp)
        ) {
            // Top bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Filled.Menu, contentDescription = "Menu", tint = MaterialTheme.colorScheme.onSurface)
                }
                Text(
                    "TECHQUICK",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
                Box {
                    Icon(Icons.Filled.Notifications, contentDescription = "Alerts", tint = MaterialTheme.colorScheme.onSurface)
                    if (state.errorBanner != null) {
                        Box(
                            Modifier
                                .align(Alignment.TopEnd)
                                .size(8.dp)
                                .background(MaterialTheme.colorScheme.error, CircleShape)
                        )
                    }
                }
            }

            Spacer(Modifier.height(6.dp))

            // Greeting row
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (isDay) Icons.Filled.WbSunny else Icons.Filled.NightsStay,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(6.dp))
                Column {
                    Text(
                        greeting,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        "Time: $timeLabel",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
            }

            state.errorBanner?.let { error ->
                Spacer(Modifier.height(8.dp))
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(error, modifier = Modifier.padding(10.dp), color = MaterialTheme.colorScheme.onErrorContainer)
                }
            }

            Spacer(Modifier.height(10.dp))

            // Widget flanks + central orb
            Row(
                modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    HudWidgetCard(state.hud.weather, tiltDegrees = 8f)
                    HudWidgetCard(state.hud.location, tiltDegrees = 8f)
                    HudWidgetCard(state.hud.calendar, tiltDegrees = 8f)
                }

                Box(
                    modifier = Modifier
                        .width(168.dp)
                        .shadow(
                            elevation = 28.dp,
                            shape = CircleShape,
                            ambientColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.5f),
                            spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    AIOrb(state = state.orbState, size = 158.dp)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "TECHQUICK",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            orbLabel(state.orbState),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    HudWidgetCard(state.hud.battery, tiltDegrees = -8f)
                    HudWidgetCard(state.hud.systemHealth, tiltDegrees = -8f)
                    HudWidgetCard(state.hud.connectivity, tiltDegrees = -8f)
                }
            }

            Spacer(Modifier.height(14.dp))

            // Transient response area — one turn at a time, never a scrollback list.
            val latest = state.messages.lastOrNull()
            AnimatedContent(
                targetState = latest,
                transitionSpec = { fadeIn(tween(280)) togetherWith fadeOut(tween(200)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(
                        elevation = 10.dp,
                        shape = RoundedCornerShape(16.dp),
                        ambientColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.3f),
                        spotColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.4f)
                    ),
                label = "response"
            ) { message ->
                ResponseArea(
                    message = message,
                    onConfirm = { msg ->
                        msg.pendingConfirmation?.let {
                            viewModel.confirmAction(msg.id, it.actionType, it.parameters)
                        }
                    },
                    onCancel = { msg -> viewModel.cancelAction(msg.id) }
                )
            }

            Spacer(Modifier.height(18.dp))

            // Mic control
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                WaveformRow(active = state.isListening)
                Spacer(Modifier.height(10.dp))
                Surface(
                    onClick = { if (!state.isListening) viewModel.startListening() },
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                    border = androidx.compose.foundation.BorderStroke(
                        2.dp,
                        if (state.isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
                    ),
                    modifier = Modifier
                        .size(72.dp)
                        .shadow(
                            elevation = 18.dp,
                            shape = CircleShape,
                            ambientColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.6f),
                            spotColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.8f)
                        )
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Filled.Mic,
                            contentDescription = "Speak to TechQuick",
                            tint = if (state.isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(30.dp)
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    if (state.isListening) "Voice Input Active" else "Speak to TechQuick",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }

            Spacer(Modifier.height(14.dp))

            InputBar(
                text = state.inputText,
                onTextChange = viewModel::onInputChange,
                onSend = { viewModel.sendMessage() },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun ResponseArea(
    message: ChatMessage?,
    onConfirm: (ChatMessage) -> Unit,
    onCancel: (ChatMessage) -> Unit
) {
    if (message == null) {
        Text(
            "Welcome back!\nHow can I assist you today?",
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.fillMaxWidth()
        )
        return
    }

    val confirmation = message.pendingConfirmation
    val actionCard = message.actionCard
    when {
        confirmation != null -> {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(
                        elevation = 10.dp,
                        shape = RoundedCornerShape(16.dp),
                        ambientColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.35f),
                        spotColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.45f)
                    )
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.7f))
                    .padding(16.dp)
            ) {
                Text(confirmation.title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                Spacer(Modifier.height(4.dp))
                Text(confirmation.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { onCancel(message) }) { Text("Cancel") }
                    Button(onClick = { onConfirm(message) }) { Text("Confirm") }
                }
            }
        }
        actionCard != null -> ActionCardView(actionCard, modifier = Modifier.fillMaxWidth())
        else -> Text(
            message.text,
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun WaveformRow(active: Boolean) {
    val accent = MaterialTheme.colorScheme.secondary
    val heights = if (active) listOf(10, 20, 28, 16, 24, 12, 18) else listOf(6, 8, 6, 10, 6, 8, 6)
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        heights.forEach { h ->
            Box(
                Modifier
                    .width(3.dp)
                    .height(h.dp)
                    .background(accent.copy(alpha = if (active) 0.9f else 0.35f), RoundedCornerShape(2.dp))
            )
        }
    }
}

@Composable
private fun rememberNowLabel(): String {
    var label by remember {
        mutableStateOf(SimpleDateFormat("h:mm a", Locale.getDefault()).format(Calendar.getInstance().time))
    }
    LaunchedEffect(Unit) {
        while (true) {
            label = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Calendar.getInstance().time)
            kotlinx.coroutines.delay(30_000)
        }
    }
    return label
}
