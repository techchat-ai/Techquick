package com.technology.techquick.model

import java.util.UUID

enum class Sender { USER, ASSISTANT }

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: Sender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val actionCard: ActionCardData? = null,
    val pendingConfirmation: PendingConfirmation? = null
)

enum class ActionCardStatus { RUNNING, COMPLETED, FAILED }

data class ActionCardData(
    val icon: String,
    val title: String,
    val subtitle: String,
    val status: ActionCardStatus,
    val detail: String? = null
)

data class PendingConfirmation(
    val actionType: String,
    val parameters: Map<String, String>,
    val title: String,
    val description: String
)
