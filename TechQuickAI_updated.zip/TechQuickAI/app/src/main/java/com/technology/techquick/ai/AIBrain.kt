package com.technology.techquick.ai

import com.technology.techquick.actions.ActionRegistry
import com.technology.techquick.data.SettingsRepository
import com.technology.techquick.model.AIActionResponse
import kotlinx.serialization.json.Json
import kotlinx.serialization.SerializationException

/**
 * The "brain" of TechQuick. Owns the system prompt (personality + strict
 * action-JSON contract), calls whichever provider the user configured, and
 * parses the reply into an AIActionResponse. It never executes anything
 * itself — that's ActionEngine's job, after ActionRegistry validates it.
 */
class AIBrain(
    private val settingsRepository: SettingsRepository,
    private val actionRegistry: ActionRegistry
) {
    private val jsonParser = Json { ignoreUnknownKeys = true; isLenient = true }

    private fun buildSystemPrompt(): String = """
        You are TechQuick, a smart, friendly, reliable Android assistant personality.
        You are intelligent, friendly, fast, confident, honest, and slightly playful (never childish or annoying).
        You understand English, Hindi, and Hinglish, and you ALWAYS reply in the same language/style the user used.
        You never pretend an action happened if it didn't. You don't ask unnecessary questions when the request is already clear.

        You do not control the phone directly. You only ever choose actions from this exact registry:
        ${actionRegistry.asPromptCatalog()}

        Rules:
        1. Reply with STRICT JSON ONLY. No prose outside the JSON. No markdown code fences.
        2. JSON shape exactly: {"response": string, "actions": [{"type": string, "parameters": {string: string}}], "needsClarification": boolean}
        3. Only use action "type" values from the registry above. Never invent a new type.
        4. If you are missing a required parameter (e.g. what a message should say, or which contact), set needsClarification=true, leave actions empty, and ask ONE short clarifying question in "response".
        5. "response" is what gets spoken/shown to the user — keep it short and natural, matching their language.
        6. For actions marked [SENSITIVE], still return them normally; the app will confirm with the user before running them, you don't need to ask yourself.
        7. If the user asks something with no matching action (general knowledge, chit-chat), just answer in "response" with an empty actions array.
    """.trimIndent()

    suspend fun process(history: List<Pair<Boolean, String>>, userMessage: String): Result<AIActionResponse> {
        val config = settingsRepository.getAIConfig()
            ?: return Result.failure(IllegalStateException("NO_API_KEY"))

        val provider = AIProviderFactory.get(config.providerType)
        val raw = provider.sendMessage(
            systemPrompt = buildSystemPrompt(),
            history = history,
            userMessage = userMessage,
            apiKey = config.apiKey,
            baseUrl = config.baseUrl,
            model = config.model
        )

        return raw.mapCatching { text ->
            parseActionJson(text)
        }
    }

    private fun parseActionJson(rawText: String): AIActionResponse {
        // Models occasionally wrap JSON in ```json fences despite instructions; strip defensively.
        val cleaned = rawText.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val jsonStart = cleaned.indexOf('{')
        val jsonEnd = cleaned.lastIndexOf('}')
        if (jsonStart == -1 || jsonEnd == -1 || jsonEnd < jsonStart) {
            // Model didn't return JSON — treat the whole reply as a plain response with no actions.
            return AIActionResponse(response = cleaned, actions = emptyList())
        }
        val jsonSlice = cleaned.substring(jsonStart, jsonEnd + 1)
        return try {
            jsonParser.decodeFromString(AIActionResponse.serializer(), jsonSlice)
        } catch (e: SerializationException) {
            AIActionResponse(response = cleaned, actions = emptyList())
        }
    }

    suspend fun testConnection(providerTypeName: String, apiKey: String, baseUrl: String, model: String): Result<Unit> {
        val type = com.technology.techquick.model.AIProviderType.fromName(providerTypeName)
        return AIProviderFactory.get(type).testConnection(apiKey, baseUrl, model)
    }
}
