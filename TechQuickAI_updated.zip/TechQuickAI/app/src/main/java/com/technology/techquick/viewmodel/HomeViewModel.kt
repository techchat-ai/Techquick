package com.technology.techquick.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.technology.techquick.TechQuickApplication
import com.technology.techquick.model.AIAction
import com.technology.techquick.model.ActionCardData
import com.technology.techquick.model.ActionCardStatus
import com.technology.techquick.model.ActionResult
import com.technology.techquick.model.ChatMessage
import com.technology.techquick.model.PendingConfirmation
import com.technology.techquick.model.Sender
import com.technology.techquick.ui.components.OrbState
import com.technology.techquick.voice.SpeechRecognizerManager
import com.technology.techquick.voice.TextToSpeechManager
import com.technology.techquick.voice.VoiceEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUiState(
    val messages: List<ChatMessage> = emptyList(),
    val orbState: OrbState = OrbState.IDLE,
    val inputText: String = "",
    val isListening: Boolean = false,
    val hasApiKey: Boolean = true,
    val errorBanner: String? = null
)

/**
 * Drives the home/conversation screen: takes user input (typed or spoken),
 * sends it to AIBrain, validates any returned actions against
 * ActionRegistry, runs safe actions immediately via ActionEngine, and
 * gates sensitive actions behind an explicit confirm/cancel in the UI.
 */
class HomeViewModel(private val app: TechQuickApplication) : ViewModel() {

    private val speech = SpeechRecognizerManager(app)
    private val tts = TextToSpeechManager(app)

    private val _orbState = MutableStateFlow(OrbState.IDLE)
    private val _inputText = MutableStateFlow("")
    private val _isListening = MutableStateFlow(false)
    private val _errorBanner = MutableStateFlow<String?>(null)

    val state: StateFlow<HomeUiState> = combine(
        app.conversationRepository.messages, _orbState, _inputText, _isListening, _errorBanner
    ) { messages, orb, input, listening, error ->
        HomeUiState(
            messages = messages,
            orbState = orb,
            inputText = input,
            isListening = listening,
            hasApiKey = app.settingsRepository.hasApiKey(),
            errorBanner = error
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUiState())

    fun onInputChange(text: String) { _inputText.value = text }

    fun onQuickAction(prompt: String, autoSend: Boolean) {
        _inputText.value = prompt
        if (autoSend) sendMessage(prompt)
    }

    fun startListening() {
        _isListening.value = true
        _orbState.value = OrbState.LISTENING
        speech.listen().onEach { event ->
            when (event) {
                is VoiceEvent.PartialResult -> _inputText.value = event.text
                is VoiceEvent.FinalResult -> {
                    _inputText.value = event.text
                    sendMessage(event.text)
                }
                is VoiceEvent.Error -> {
                    _errorBanner.value = event.message
                    _isListening.value = false
                    _orbState.value = OrbState.IDLE
                }
                VoiceEvent.Done -> _isListening.value = false
                VoiceEvent.Listening -> {}
            }
        }.launchIn(viewModelScope)
    }

    fun sendMessage(text: String = _inputText.value) {
        if (text.isBlank()) return
        if (!app.settingsRepository.hasApiKey()) {
            _errorBanner.value = "Connect your AI brain to continue."
            return
        }

        _inputText.value = ""
        app.conversationRepository.add(ChatMessage(sender = Sender.USER, text = text))
        _orbState.value = OrbState.THINKING

        viewModelScope.launch {
            val history = app.conversationRepository.historyForAI().dropLast(1)
            val result = app.aiBrain.process(history, text)

            result.fold(
                onSuccess = { aiResponse ->
                    app.conversationRepository.add(ChatMessage(sender = Sender.ASSISTANT, text = aiResponse.response))
                    if (app.settingsRepository.voiceResponsesEnabled) tts.speak(aiResponse.response)

                    if (aiResponse.actions.isEmpty()) {
                        _orbState.value = OrbState.FINISHED
                        return@fold
                    }

                    for (action in aiResponse.actions) {
                        if (!app.actionRegistry.isRegistered(action.type)) continue

                        if (app.actionRegistry.isSensitive(action.type)) {
                            requestConfirmation(action)
                        } else {
                            runAction(action)
                        }
                    }
                    _orbState.value = OrbState.FINISHED
                },
                onFailure = { error ->
                    val message = if (error.message == "NO_API_KEY")
                        "Connect your AI brain to continue."
                    else
                        "I can't reach the AI right now. Check your internet connection."
                    app.conversationRepository.add(ChatMessage(sender = Sender.ASSISTANT, text = message))
                    _orbState.value = OrbState.IDLE
                }
            )
        }
    }

    private fun requestConfirmation(action: AIAction) {
        val def = app.actionRegistry.definitionFor(action.type)
        val desc = action.parameters.entries.joinToString("\n") { "${it.key}: ${it.value}" }
        app.conversationRepository.add(
            ChatMessage(
                sender = Sender.ASSISTANT,
                text = "This needs your confirmation:",
                pendingConfirmation = PendingConfirmation(
                    actionType = action.type,
                    parameters = action.parameters,
                    title = def?.description ?: action.type,
                    description = desc.ifBlank { "Proceed with this action?" }
                )
            )
        )
    }

    fun confirmAction(messageId: String, actionType: String, parameters: Map<String, String>) {
        app.conversationRepository.replace(messageId) { it.copy(pendingConfirmation = null) }
        viewModelScope.launch { runAction(AIAction(actionType, parameters)) }
    }

    fun cancelAction(messageId: String) {
        app.conversationRepository.replace(messageId) { it.copy(pendingConfirmation = null) }
        app.conversationRepository.add(ChatMessage(sender = Sender.ASSISTANT, text = "Okay, cancelled."))
    }

    private suspend fun runAction(action: AIAction) {
        _orbState.value = OrbState.EXECUTING
        val def = app.actionRegistry.definitionFor(action.type)
        val runningCard = ChatMessage(
            sender = Sender.ASSISTANT,
            text = "",
            actionCard = ActionCardData(
                icon = "\u2699\uFE0F",
                title = def?.description ?: action.type,
                subtitle = action.parameters.values.joinToString(", "),
                status = ActionCardStatus.RUNNING
            )
        )
        app.conversationRepository.add(runningCard)

        val result = app.actionEngine.execute(action)

        app.conversationRepository.replace(runningCard.id) { msg ->
            when (result) {
                is ActionResult.Success -> msg.copy(
                    actionCard = msg.actionCard?.copy(
                        status = ActionCardStatus.COMPLETED,
                        subtitle = result.detail ?: msg.actionCard.subtitle
                    )
                )
                is ActionResult.Failure -> msg.copy(
                    actionCard = msg.actionCard?.copy(status = ActionCardStatus.FAILED, detail = result.reason)
                )
            }
        }

        val summary = when (result) {
            is ActionResult.Success -> result.summary
            is ActionResult.Failure -> "I couldn't complete that action. ${result.reason}"
        }
        app.conversationRepository.add(ChatMessage(sender = Sender.ASSISTANT, text = summary))
        if (app.settingsRepository.voiceResponsesEnabled) tts.speak(summary)
    }

    fun dismissError() { _errorBanner.value = null }

    override fun onCleared() {
        tts.shutdown()
        super.onCleared()
    }

    companion object {
        fun factory(app: TechQuickApplication) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = HomeViewModel(app) as T
        }
    }
}
