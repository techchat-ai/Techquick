package com.technology.techquick.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.technology.techquick.TechQuickApplication
import com.technology.techquick.device.DeviceStatusProvider
import com.technology.techquick.device.HudStat
import com.technology.techquick.device.WeatherProvider
import com.technology.techquick.model.AIAction
import com.technology.techquick.model.ActionCardData
import com.technology.techquick.model.ActionCardStatus
import com.technology.techquick.model.ActionResult
import com.technology.techquick.model.ChatMessage
import com.technology.techquick.model.PendingConfirmation
import com.technology.techquick.model.Sender
import com.technology.techquick.ui.components.OrbState
import com.technology.techquick.voice.SpeechRecognizerManager
import com.technology.techquick.voice.TextToSpeechManager
import com.technology.techquick.voice.VoiceEvent
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HudUiState(
    val weather: HudStat = HudStat("WEATHER", "Loading..."),
    val battery: HudStat = HudStat("BATTERY", "..."),
    val location: HudStat = HudStat("LOCATION", "Finding..."),
    val systemHealth: HudStat = HudStat("SYSTEM HEALTH", "..."),
    val calendar: HudStat = HudStat("CALENDAR", "Loading..."),
    val connectivity: HudStat = HudStat("CONNECTIVITY", "...")
)

data class HomeUiState(
    val messages: List<ChatMessage> = emptyList(),
    val orbState: OrbState = OrbState.IDLE,
    val inputText: String = "",
    val isListening: Boolean = false,
    val hasApiKey: Boolean = true,
    val errorBanner: String? = null,
    val continuousListening: Boolean = false,
    val hud: HudUiState = HudUiState()
)

/** Words that confirm or cancel a pending sensitive action, spoken or typed, in English/Hindi/Hinglish. */
private val CONFIRM_WORDS = setOf(
    "yes", "confirm", "confirmed", "ok", "okay", "go ahead", "do it", "sure",
    "haan", "han", "haanji", "ha", "kar do", "karo", "confirm karo", "bilkul", "theek hai", "thik hai"
)
private val CANCEL_WORDS = setOf(
    "no", "cancel", "cancelled", "stop", "don't", "dont",
    "nahi", "nahin", "mat karo", "rehne do", "cancel karo"
)

/**
 * Drives the home/conversation screen: takes user input (typed or spoken),
 * sends it to AIBrain, validates any returned actions against
 * ActionRegistry, runs safe actions immediately via ActionEngine, and
 * gates sensitive actions behind an explicit confirm/cancel in the UI.
 */
class HomeViewModel(private val app: TechQuickApplication) : ViewModel() {

    private val speech = SpeechRecognizerManager(app)
    private val tts = TextToSpeechManager(app)

    private val _orbState = MutableStateFlow(OrbState.IDLE)
    private val _inputText = MutableStateFlow("")
    private val _isListening = MutableStateFlow(false)
    private val _errorBanner = MutableStateFlow<String?>(null)
    private val _continuousListening = MutableStateFlow(app.settingsRepository.continuousListeningEnabled)
    private val _hud = MutableStateFlow(HudUiState())

    init {
        refreshHud()
        // Vitals drift slowly (battery drains, network can flip) so a light
        // periodic refresh keeps the HUD honest without hammering anything.
        viewModelScope.launch {
            while (true) {
                delay(60_000)
                refreshHud()
            }
        }
    }

    private fun refreshHud() {
        _hud.value = _hud.value.copy(
            battery = DeviceStatusProvider.battery(app),
            connectivity = DeviceStatusProvider.connectivity(app),
            systemHealth = DeviceStatusProvider.systemHealth(app)
        )
        viewModelScope.launch {
            _hud.value = _hud.value.copy(location = DeviceStatusProvider.location(app))
            _hud.value = _hud.value.copy(calendar = DeviceStatusProvider.nextCalendarEvent(app))
            val latLon = DeviceStatusProvider.lastKnownLatLon(app)
            _hud.value = _hud.value.copy(
                weather = if (latLon != null) WeatherProvider.fetch(latLon.first, latLon.second)
                else HudStat("WEATHER", "Enable location")
            )
        }
    }

    val state: StateFlow<HomeUiState> = combine(
        app.conversationRepository.messages, _orbState, _inputText, _isListening, _errorBanner, _continuousListening, _hud
    ) { flows ->
        HomeUiState(
            messages = flows[0] as List<com.technology.techquick.model.ChatMessage>,
            orbState = flows[1] as OrbState,
            inputText = flows[2] as String,
            isListening = flows[3] as Boolean,
            hasApiKey = app.settingsRepository.hasApiKey(),
            errorBanner = flows[4] as String?,
            continuousListening = flows[5] as Boolean,
            hud = flows[6] as HudUiState
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUiState())

    fun setContinuousListening(enabled: Boolean) {
        app.settingsRepository.continuousListeningEnabled = enabled
        _continuousListening.value = enabled
        if (enabled && !_isListening.value) startListening()
    }

    fun onInputChange(text: String) { _inputText.value = text }

    fun onQuickAction(prompt: String, autoSend: Boolean) {
        _inputText.value = prompt
        if (autoSend) sendMessage(prompt)
    }

    fun startListening() {
        _isListening.value = true
        _orbState.value = OrbState.LISTENING
        speech.listen().onEach { event ->
            when (event) {
                is VoiceEvent.PartialResult -> _inputText.value = event.text
                is VoiceEvent.FinalResult -> {
                    _inputText.value = event.text
                    sendMessage(event.text)
                }
                is VoiceEvent.Error -> {
                    _isListening.value = false
                    _orbState.value = OrbState.IDLE
                    // In continuous mode, transient errors like "no speech" shouldn't
                    // surface as a banner every few seconds — just quietly re-listen.
                    if (_continuousListening.value) {
                        viewModelScope.launch { startListening() }
                    } else {
                        _errorBanner.value = event.message
                    }
                }
                VoiceEvent.Done -> {
                    _isListening.value = false
                    // Jarvis mode: keep the mic open turn after turn with no re-tap needed,
                    // as long as we're not mid-response and there's no confirmation pending.
                    if (_continuousListening.value &&
                        _orbState.value != OrbState.THINKING &&
                        _orbState.value != OrbState.EXECUTING
                    ) {
                        viewModelScope.launch { startListening() }
                    }
                }
                VoiceEvent.Listening -> {}
            }
        }.launchIn(viewModelScope)
    }

    /** If there's an unresolved confirmation and this text is a clear yes/no, resolve it directly. */
    private fun tryResolvePendingConfirmation(text: String): Boolean {
        val pending = app.conversationRepository.messages.value.lastOrNull { it.pendingConfirmation != null }
            ?: return false
        val normalized = text.trim().lowercase().trimEnd('.', '!', '?')
        return when {
            CONFIRM_WORDS.any { normalized == it || normalized.startsWith("$it ") } -> {
                pending.pendingConfirmation?.let { confirmAction(pending.id, it.actionType, it.parameters) }
                true
            }
            CANCEL_WORDS.any { normalized == it || normalized.startsWith("$it ") } -> {
                cancelAction(pending.id)
                true
            }
            else -> false
        }
    }

    fun sendMessage(text: String = _inputText.value) {
        if (text.isBlank()) return
        if (!app.settingsRepository.hasApiKey()) {
            _errorBanner.value = "Connect your AI brain to continue."
            return
        }

        _inputText.value = ""

        if (tryResolvePendingConfirmation(text)) {
            if (_continuousListening.value) startListening()
            return
        }
        app.conversationRepository.add(ChatMessage(sender = Sender.USER, text = text))
        _orbState.value = OrbState.THINKING

        viewModelScope.launch {
            val history = app.conversationRepository.historyForAI().dropLast(1)
            val result = app.aiBrain.process(history, text)

            result.fold(
                onSuccess = { aiResponse ->
                    app.conversationRepository.add(ChatMessage(sender = Sender.ASSISTANT, text = aiResponse.response))
                    if (app.settingsRepository.voiceResponsesEnabled) tts.speak(aiResponse.response)

                    if (aiResponse.actions.isEmpty()) {
                        _orbState.value = OrbState.FINISHED
                        return@fold
                    }

                    for (action in aiResponse.actions) {
                        if (!app.actionRegistry.isRegistered(action.type)) continue

                        if (app.actionRegistry.isSensitive(action.type)) {
                            requestConfirmation(action)
                        } else {
                            runAction(action)
                        }
                    }
                    _orbState.value = OrbState.FINISHED
                },
                onFailure = { error ->
                    val message = if (error.message == "NO_API_KEY")
                        "Connect your AI brain to continue."
                    else
                        "I can't reach the AI right now. Check your internet connection."
                    app.conversationRepository.add(ChatMessage(sender = Sender.ASSISTANT, text = message))
                    _orbState.value = OrbState.IDLE
                }
            )
            if (_continuousListening.value && !_isListening.value) startListening()
        }
    }

    private fun requestConfirmation(action: AIAction) {
        val def = app.actionRegistry.definitionFor(action.type)
        val desc = action.parameters.entries.joinToString("\n") { "${it.key}: ${it.value}" }
        app.conversationRepository.add(
            ChatMessage(
                sender = Sender.ASSISTANT,
                text = "This needs your confirmation:",
                pendingConfirmation = PendingConfirmation(
                    actionType = action.type,
                    parameters = action.parameters,
                    title = def?.description ?: action.type,
                    description = desc.ifBlank { "Proceed with this action?" }
                )
            )
        )
    }

    fun confirmAction(messageId: String, actionType: String, parameters: Map<String, String>) {
        app.conversationRepository.replace(messageId) { it.copy(pendingConfirmation = null) }
        viewModelScope.launch { runAction(AIAction(actionType, parameters)) }
    }

    fun cancelAction(messageId: String) {
        app.conversationRepository.replace(messageId) { it.copy(pendingConfirmation = null) }
        app.conversationRepository.add(ChatMessage(sender = Sender.ASSISTANT, text = "Okay, cancelled."))
    }

    private suspend fun runAction(action: AIAction) {
        _orbState.value = OrbState.EXECUTING
        val def = app.actionRegistry.definitionFor(action.type)
        val runningCard = ChatMessage(
            sender = Sender.ASSISTANT,
            text = "",
            actionCard = ActionCardData(
                icon = "\u2699\uFE0F",
                title = def?.description ?: action.type,
                subtitle = action.parameters.values.joinToString(", "),
                status = ActionCardStatus.RUNNING
            )
        )
        app.conversationRepository.add(runningCard)

        val result = app.actionEngine.execute(action)

        app.conversationRepository.replace(runningCard.id) { msg ->
            when (result) {
                is ActionResult.Success -> msg.copy(
                    actionCard = msg.actionCard?.copy(
                        status = ActionCardStatus.COMPLETED,
                        subtitle = result.detail ?: msg.actionCard.subtitle
                    )
                )
                is ActionResult.Failure -> msg.copy(
                    actionCard = msg.actionCard?.copy(status = ActionCardStatus.FAILED, detail = result.reason)
                )
            }
        }

        val summary = when (result) {
            is ActionResult.Success -> result.summary
            is ActionResult.Failure -> "I couldn't complete that action. ${result.reason}"
        }
        app.conversationRepository.add(ChatMessage(sender = Sender.ASSISTANT, text = summary))
        if (app.settingsRepository.voiceResponsesEnabled) tts.speak(summary)
    }

    fun dismissError() { _errorBanner.value = null }

    override fun onCleared() {
        tts.shutdown()
        super.onCleared()
    }

    companion object {
        fun factory(app: TechQuickApplication) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = HomeViewModel(app) as T
        }
    }
}
