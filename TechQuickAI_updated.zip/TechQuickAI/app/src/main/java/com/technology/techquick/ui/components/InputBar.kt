package com.technology.techquick.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import com.technology.techquick.ui.theme.HudCyan
import com.technology.techquick.ui.theme.HudCyanBright
import com.technology.techquick.ui.theme.HudPanelFill
import com.technology.techquick.ui.theme.HudTextBright
import com.technology.techquick.ui.theme.HudTextMuted

/**
 * Bottom command capsule. The mic is NOT here — the central orb-mic button
 * owns voice input; this is a glass field for typed queries plus a glowing
 * send arrow, matching the reference HUD's input bar exactly. Fixed HUD
 * palette so it always reads as a terminal, regardless of theme toggle.
 */
@Composable
fun InputBar(
    text: String,
    onTextChange: (String) -> Unit,
    onSend: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .shadow(
                elevation = 10.dp,
                shape = RoundedCornerShape(28.dp),
                ambientColor = HudCyan.copy(alpha = 0.35f),
                spotColor = HudCyanBright.copy(alpha = 0.4f)
            ),
        color = HudPanelFill.copy(alpha = 0.65f),
        shape = RoundedCornerShape(28.dp),
        border = BorderStroke(1.dp, HudCyan.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = text,
                onValueChange = onTextChange,
                modifier = Modifier.weight(1f),
                textStyle = TextStyle(color = HudTextBright),
                placeholder = {
                    Text("Type your query here...", color = HudTextMuted)
                },
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedBorderColor = androidx.compose.ui.graphics.Color.Transparent,
                    focusedBorderColor = androidx.compose.ui.graphics.Color.Transparent,
                    unfocusedTextColor = HudTextBright,
                    focusedTextColor = HudTextBright,
                    cursorColor = HudCyanBright
                ),
                singleLine = true
            )
            IconButton(onClick = onSend) {
                Surface(
                    shape = CircleShape,
                    color = HudCyan.copy(alpha = 0.18f),
                    border = BorderStroke(1.dp, HudCyanBright.copy(alpha = 0.7f)),
                    modifier = Modifier
                        .shadow(elevation = 6.dp, shape = CircleShape, ambientColor = HudCyanBright.copy(alpha = 0.6f))
                ) {
                    Icon(
                        Icons.Filled.Send,
                        contentDescription = "Send",
                        tint = HudCyanBright,
                        modifier = Modifier.padding(7.dp)
                    )
                }
            }
        }
    }
}
