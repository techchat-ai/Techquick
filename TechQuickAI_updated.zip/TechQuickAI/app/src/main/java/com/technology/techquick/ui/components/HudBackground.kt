package com.technology.techquick.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import com.technology.techquick.ui.theme.HudCyan
import com.technology.techquick.ui.theme.HudCyanDim
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Faint animated HUD texture behind the interface: a low-opacity hex grid,
 * corner circuit accents, a soft ambient cyan haze where the orb sits, and
 * a slow scanning line — deliberately understated so it reads as cinematic
 * texture rather than a second focal point. Uses the fixed HUD palette (not
 * MaterialTheme) so it never shifts with the light/dark toggle.
 */
@Composable
fun HudBackground(modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "hudBg")
    val scanFraction by infinite.animateFloat(
        initialValue = -0.15f, targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "scan"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        // Ambient haze where the orb sits, so the console feels lit and
        // occupied rather than a flat black rectangle.
        drawCircle(
            brush = Brush.radialGradient(
                listOf(HudCyan.copy(alpha = 0.10f), Color.Transparent),
                center = Offset(size.width * 0.5f, size.height * 0.34f),
                radius = size.width * 0.95f
            ),
            radius = size.width * 0.95f,
            center = Offset(size.width * 0.5f, size.height * 0.34f)
        )

        val hexRadius = 34f
        val hexHeight = hexRadius * 2f
        val hexWidth = hexRadius * 1.732f
        val stroke = Stroke(width = 1f, cap = StrokeCap.Round)

        var row = 0
        var y = -hexHeight / 2f
        while (y < size.height + hexHeight) {
            val xOffset = if (row % 2 == 0) 0f else hexWidth / 2f
            var x = -hexWidth / 2f + xOffset
            while (x < size.width + hexWidth) {
                val path = Path().apply {
                    for (i in 0..6) {
                        val angle = (PI / 3.0 * i - PI / 6.0).toFloat()
                        val px = x + hexRadius * cos(angle)
                        val py = y + hexRadius * sin(angle)
                        if (i == 0) moveTo(px, py) else lineTo(px, py)
                    }
                }
                drawPath(path, color = HudCyanDim.copy(alpha = 0.05f), style = stroke)
                x += hexWidth
            }
            y += hexHeight * 0.75f
            row++
        }

        // Corner circuit accents
        val cornerLen = size.width * 0.14f
        drawLine(HudCyan.copy(alpha = 0.18f), Offset(0f, cornerLen), Offset(0f, 0f), 2f)
        drawLine(HudCyan.copy(alpha = 0.18f), Offset(0f, 0f), Offset(cornerLen, 0f), 2f)
        drawLine(HudCyan.copy(alpha = 0.18f), Offset(size.width, size.height - cornerLen), Offset(size.width, size.height), 2f)
        drawLine(HudCyan.copy(alpha = 0.18f), Offset(size.width - cornerLen, size.height), Offset(size.width, size.height), 2f)

        // Slow scanning line, barely visible — purely ambient motion
        val scanY = size.height * scanFraction
        drawRect(
            brush = Brush.verticalGradient(
                listOf(Color.Transparent, HudCyan.copy(alpha = 0.05f), Color.Transparent),
                startY = scanY - 40f, endY = scanY + 40f
            ),
            topLeft = Offset(0f, scanY - 40f),
            size = Size(size.width, 80f)
        )
    }
}
