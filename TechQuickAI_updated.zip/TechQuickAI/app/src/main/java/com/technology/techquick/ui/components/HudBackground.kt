package com.technology.techquick.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.PI

/**
 * A faint, static hex-grid + corner circuit-line texture, evoking the HUD
 * reference without competing with the orb or the widget text. Alpha stays
 * low on purpose — this is ambient texture, not a second focal point.
 */
@Composable
fun HudBackground(modifier: Modifier = Modifier) {
    val accent = MaterialTheme.colorScheme.secondary
    Canvas(modifier = modifier.fillMaxSize()) {
        val hexRadius = 34f
        val hexHeight = hexRadius * 2f
        val hexWidth = hexRadius * 1.732f
        val stroke = Stroke(width = 1f, cap = StrokeCap.Round)

        var row = 0
        var y = -hexHeight / 2f
        while (y < size.height + hexHeight) {
            val xOffset = if (row % 2 == 0) 0f else hexWidth / 2f
            var x = -hexWidth / 2f + xOffset
            while (x < size.width + hexWidth) {
                val path = androidx.compose.ui.graphics.Path().apply {
                    for (i in 0..6) {
                        val angle = (PI / 3.0 * i - PI / 6.0).toFloat()
                        val px = x + hexRadius * cos(angle)
                        val py = y + hexRadius * sin(angle)
                        if (i == 0) moveTo(px, py) else lineTo(px, py)
                    }
                }
                drawPath(path, color = accent.copy(alpha = 0.05f), style = stroke)
                x += hexWidth
            }
            y += hexHeight * 0.75f
            row++
        }

        // Corner circuit accents
        val cornerLen = size.width * 0.14f
        drawLine(accent.copy(alpha = 0.18f), Offset(0f, cornerLen), Offset(0f, 0f), 2f)
        drawLine(accent.copy(alpha = 0.18f), Offset(0f, 0f), Offset(cornerLen, 0f), 2f)
        drawLine(accent.copy(alpha = 0.18f), Offset(size.width, size.height - cornerLen), Offset(size.width, size.height), 2f)
        drawLine(accent.copy(alpha = 0.18f), Offset(size.width - cornerLen, size.height), Offset(size.width, size.height), 2f)
    }
}
