package com.technology.techquick.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.technology.techquick.TechQuickApplication
import com.technology.techquick.data.AssistantMood
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class PersonalityUiState(
    val assistantName: String = "TechQuick",
    val mood: AssistantMood = AssistantMood.FRIENDLY,
    val customInstructions: String = ""
)

class PersonalityViewModel(private val app: TechQuickApplication) : ViewModel() {

    val state: StateFlow<PersonalityUiState> = combine(
        app.personalityRepository.assistantName,
        app.personalityRepository.mood,
        app.personalityRepository.customInstructions
    ) { name, mood, custom -> PersonalityUiState(name, mood, custom) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PersonalityUiState())

    fun setMood(mood: AssistantMood) = app.personalityRepository.setMood(mood)
    fun setAssistantName(name: String) = app.personalityRepository.setAssistantName(name)
    fun setCustomInstructions(text: String) = app.personalityRepository.setCustomInstructions(text)

    companion object {
        fun factory(app: TechQuickApplication) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = PersonalityViewModel(app) as T
        }
    }
}
