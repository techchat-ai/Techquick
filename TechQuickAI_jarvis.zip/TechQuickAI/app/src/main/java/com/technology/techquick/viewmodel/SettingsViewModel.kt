package com.technology.techquick.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.technology.techquick.TechQuickApplication
import com.technology.techquick.actions.impl.DeviceActions
import com.technology.techquick.data.AppTheme
import com.technology.techquick.data.ResponseStyle
import com.technology.techquick.model.AIProviderType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class SettingsUiState(
    val theme: AppTheme = AppTheme.SYSTEM,
    val voiceResponsesEnabled: Boolean = true,
    val responseStyle: ResponseStyle = ResponseStyle.CONCISE,
    val providerName: String = "",
    val hasApiKey: Boolean = false,
    val deviceAdminActive: Boolean = false
)

class SettingsViewModel(private val app: TechQuickApplication) : ViewModel() {

    private val deviceActions = DeviceActions(app)

    private val _state = MutableStateFlow(loadState())
    val state: StateFlow<SettingsUiState> = _state

    private fun loadState(): SettingsUiState {
        val config = app.settingsRepository.getAIConfig()
        return SettingsUiState(
            theme = app.settingsRepository.theme.value,
            voiceResponsesEnabled = app.settingsRepository.voiceResponsesEnabled,
            responseStyle = app.settingsRepository.responseStyle,
            providerName = config?.providerType?.displayName ?: "Not connected",
            hasApiKey = app.settingsRepository.hasApiKey(),
            deviceAdminActive = deviceActions.isDeviceAdminActive()
        )
    }

    fun deviceAdminIntent() = deviceActions.requestDeviceAdminIntent()

    fun refresh() { _state.value = loadState() }

    fun setTheme(theme: AppTheme) {
        app.settingsRepository.setTheme(theme)
        refresh()
    }

    fun setVoiceResponses(enabled: Boolean) {
        app.settingsRepository.voiceResponsesEnabled = enabled
        refresh()
    }

    fun setResponseStyle(style: ResponseStyle) {
        app.settingsRepository.responseStyle = style
        refresh()
    }

    fun removeApiKey() {
        app.settingsRepository.removeApiKey()
        app.conversationRepository.clear()
        refresh()
    }

    fun clearConversationHistory() {
        app.conversationRepository.clear()
    }

    fun testCurrentConnection(onResult: (Boolean) -> Unit) {
        val config = app.settingsRepository.getAIConfig() ?: run { onResult(false); return }
        viewModelScope.launch {
            val result = app.aiBrain.testConnection(config.providerType.name, config.apiKey, config.baseUrl, config.model)
            onResult(result.isSuccess)
        }
    }

    companion object {
        fun factory(app: TechQuickApplication) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = SettingsViewModel(app) as T
        }
    }
}
