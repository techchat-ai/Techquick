package com.technology.techquick.data

import android.content.Context
import android.content.SharedPreferences
import com.technology.techquick.model.AIProviderType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class AppTheme { LIGHT, DARK, SYSTEM }
enum class ResponseStyle { CONCISE, DETAILED }

data class AIConfig(
    val providerType: AIProviderType,
    val apiKey: String,
    val baseUrl: String,
    val model: String
)

/**
 * Non-secret app preferences (theme, language, voice on/off, response
 * style). API key material always lives in SecureStorage, never here.
 */
class SettingsRepository(context: Context, private val secureStorage: SecureStorage) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("techquick_settings", Context.MODE_PRIVATE)

    private val _theme = MutableStateFlow(loadTheme())
    val theme: StateFlow<AppTheme> = _theme

    fun setTheme(theme: AppTheme) {
        prefs.edit().putString(KEY_THEME, theme.name).apply()
        _theme.value = theme
    }
    private fun loadTheme(): AppTheme =
        AppTheme.entries.firstOrNull { it.name == prefs.getString(KEY_THEME, AppTheme.SYSTEM.name) } ?: AppTheme.SYSTEM

    var voiceResponsesEnabled: Boolean
        get() = prefs.getBoolean(KEY_VOICE_ON, true)
        set(value) = prefs.edit().putBoolean(KEY_VOICE_ON, value).apply()

    var responseStyle: ResponseStyle
        get() = ResponseStyle.entries.firstOrNull { it.name == prefs.getString(KEY_STYLE, ResponseStyle.CONCISE.name) } ?: ResponseStyle.CONCISE
        set(value) = prefs.edit().putString(KEY_STYLE, value.name).apply()

    var assistantLanguage: String
        get() = prefs.getString(KEY_LANGUAGE, "Auto (matches you)") ?: "Auto (matches you)"
        set(value) = prefs.edit().putString(KEY_LANGUAGE, value).apply()

    /** Jarvis mode: mic keeps re-listening after every reply instead of requiring a tap each time. */
    var continuousListeningEnabled: Boolean
        get() = prefs.getBoolean(KEY_CONTINUOUS_LISTEN, false)
        set(value) = prefs.edit().putBoolean(KEY_CONTINUOUS_LISTEN, value).apply()

    // --- AI Brain config (provider metadata is here; secret key is in SecureStorage) ---

    fun saveAIConfig(providerType: AIProviderType, apiKey: String, baseUrl: String, model: String) {
        secureStorage.saveApiKey(apiKey)
        secureStorage.saveProvider(providerType.name)
        secureStorage.saveBaseUrl(baseUrl)
        secureStorage.saveModel(model)
    }

    fun getAIConfig(): AIConfig? {
        if (!secureStorage.hasValidConfig()) return null
        val type = AIProviderType.fromName(secureStorage.getProvider())
        return AIConfig(
            providerType = type,
            apiKey = secureStorage.getApiKey().orEmpty(),
            baseUrl = secureStorage.getBaseUrl()?.takeIf { it.isNotBlank() } ?: type.defaultBaseUrl,
            model = secureStorage.getModel()?.takeIf { it.isNotBlank() } ?: type.defaultModel
        )
    }

    fun hasApiKey(): Boolean = secureStorage.hasValidConfig()

    fun removeApiKey() = secureStorage.clearAll()

    private companion object {
        const val KEY_THEME = "theme"
        const val KEY_VOICE_ON = "voice_responses_on"
        const val KEY_STYLE = "response_style"
        const val KEY_LANGUAGE = "assistant_language"
        const val KEY_CONTINUOUS_LISTEN = "continuous_listening"
    }
}
