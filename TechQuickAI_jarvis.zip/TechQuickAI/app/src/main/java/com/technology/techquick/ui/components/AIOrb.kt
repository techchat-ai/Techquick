package com.technology.techquick.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.min

enum class OrbState { IDLE, LISTENING, THINKING, EXECUTING, FINISHED }

/**
 * TechQuick's Jarvis-style HUD core: a stack of independently rotating
 * arc rings (one clockwise, one anti-clockwise) around a glowing plasma
 * core, built entirely with Canvas + Compose animation — no assets, so it
 * scales crisply and reacts instantly to state changes.
 */
@Composable
fun AIOrb(state: OrbState, modifier: Modifier = Modifier, size: Dp = 220.dp) {
    val infinite = rememberInfiniteTransition(label = "orb")

    // Outer ring: clockwise, speed reacts to state
    val cwSpeedMs = when (state) {
        OrbState.LISTENING -> 2600
        OrbState.THINKING -> 1400
        OrbState.EXECUTING -> 1000
        else -> 6000
    }
    val clockwiseRotation by infinite.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(cwSpeedMs, easing = LinearEasing)), label = "cw"
    )

    // Inner ring: anti-clockwise, always a bit faster for a "spinning gyroscope" feel
    val ccwSpeedMs = when (state) {
        OrbState.LISTENING -> 1800
        OrbState.THINKING -> 950
        OrbState.EXECUTING -> 700
        else -> 4200
    }
    val counterRotation by infinite.animateFloat(
        initialValue = 360f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(ccwSpeedMs, easing = LinearEasing)), label = "ccw"
    )

    // Outermost dashed ring: slow clockwise drift, always visible (idle "alive" feel)
    val driftRotation by infinite.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "drift"
    )

    val corePulse by infinite.animateFloat(
        initialValue = if (state == OrbState.LISTENING) 0.92f else 0.97f,
        targetValue = if (state == OrbState.LISTENING) 1.12f else 1.03f,
        animationSpec = infiniteRepeatable(
            tween(if (state == OrbState.LISTENING) 550 else 2000, easing = LinearEasing),
            RepeatMode.Reverse
        ), label = "corePulse"
    )

    val colors = MaterialTheme.colorScheme
    val accent = when (state) {
        OrbState.LISTENING -> colors.secondary
        OrbState.THINKING -> colors.tertiary
        OrbState.EXECUTING -> colors.primary
        else -> colors.primary
    }

    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        // Ambient glow behind everything
        Box(
            Modifier
                .size(size * 0.9f)
                .blur(36.dp)
                .background(
                    Brush.radialGradient(listOf(accent.copy(alpha = 0.55f), Color.Transparent)),
                    CircleShape
                )
        )

        Canvas(modifier = Modifier.size(size)) {
            val d = min(this.size.width, this.size.height)
            val stroke = d * 0.014f

            // Outer dashed HUD ring — slow constant drift
            rotate(driftRotation) {
                drawArc(
                    color = accent.copy(alpha = 0.35f),
                    startAngle = 0f, sweepAngle = 260f, useCenter = false,
                    style = Stroke(width = stroke, cap = StrokeCap.Round),
                    topLeft = Offset((this.size.width - d * 0.98f) / 2f, (this.size.height - d * 0.98f) / 2f),
                    size = androidx.compose.ui.geometry.Size(d * 0.98f, d * 0.98f)
                )
            }

            // Main clockwise arc ring
            rotate(clockwiseRotation) {
                drawArc(
                    brush = Brush.sweepGradient(listOf(Color.Transparent, accent, accent, Color.Transparent)),
                    startAngle = 0f, sweepAngle = 300f, useCenter = false,
                    style = Stroke(width = stroke * 1.6f, cap = StrokeCap.Round),
                    topLeft = Offset((this.size.width - d * 0.82f) / 2f, (this.size.height - d * 0.82f) / 2f),
                    size = androidx.compose.ui.geometry.Size(d * 0.82f, d * 0.82f)
                )
            }

            // Inner anti-clockwise ring
            rotate(counterRotation) {
                drawArc(
                    brush = Brush.sweepGradient(listOf(Color.Transparent, colors.tertiary, Color.Transparent)),
                    startAngle = 0f, sweepAngle = 220f, useCenter = false,
                    style = Stroke(width = stroke * 1.2f, cap = StrokeCap.Round),
                    topLeft = Offset((this.size.width - d * 0.62f) / 2f, (this.size.height - d * 0.62f) / 2f),
                    size = androidx.compose.ui.geometry.Size(d * 0.62f, d * 0.62f)
                )
            }
        }

        // Glowing plasma core
        Box(
            Modifier
                .size(size * 0.4f * corePulse)
                .background(
                    Brush.radialGradient(
                        listOf(colors.surface.copy(alpha = 0.9f), accent, colors.secondary),
                        center = Offset(0.35f, 0.3f)
                    ),
                    CircleShape
                )
        )
        Box(
            Modifier
                .size(size * 0.14f)
                .background(colors.surface.copy(alpha = 0.35f), CircleShape)
        )
    }
}
