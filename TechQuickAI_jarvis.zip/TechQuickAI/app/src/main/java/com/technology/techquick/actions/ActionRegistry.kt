package com.technology.techquick.actions

import com.technology.techquick.model.ActionDefinition

/**
 * The single source of truth for which actions exist and whether they are
 * "sensitive" (need user confirmation before executing).
 *
 * The AI brain is only ever told about the actions listed here, and the
 * ActionEngine refuses to run anything whose type isn't registered.
 * Unknown action types coming back from the AI are rejected outright —
 * this is what keeps TechQuick from ever executing arbitrary AI output.
 */
class ActionRegistry {

    private val definitions: List<ActionDefinition> = listOf(
        ActionDefinition("set_volume", "Set media volume to an exact percentage (0-100)", listOf("percentage"), false),
        ActionDefinition("increase_volume", "Increase media volume by a step", listOf("amount"), false),
        ActionDefinition("decrease_volume", "Decrease media volume by a step", listOf("amount"), false),
        ActionDefinition("flashlight_on", "Turn the flashlight/torch on", emptyList(), false),
        ActionDefinition("flashlight_off", "Turn the flashlight/torch off", emptyList(), false),
        ActionDefinition("get_time", "Get the current time", emptyList(), false),
        ActionDefinition("get_date", "Get the current date", emptyList(), false),
        ActionDefinition("open_app", "Open an installed application by name", listOf("app_name"), false),
        ActionDefinition("web_search", "Search the web for a query", listOf("query"), false),
        ActionDefinition("youtube_search", "Search YouTube for a query", listOf("query"), false),
        ActionDefinition("play_store_search", "Search the Play Store for an app", listOf("query"), false),
        ActionDefinition("maps_open", "Open Google Maps", emptyList(), false),
        ActionDefinition("maps_search", "Search a location/place on Google Maps", listOf("query"), false),
        ActionDefinition("whatsapp_open", "Open WhatsApp", emptyList(), false),
        ActionDefinition("whatsapp_message", "Prepare (and after confirmation, send) a WhatsApp message to a contact", listOf("contact_name", "message"), true),
        ActionDefinition("open_dialer", "Open the phone dialer", listOf("phone_number"), false),
        ActionDefinition("call_contact", "Call a contact or number", listOf("contact_name_or_number"), true),
        ActionDefinition("calculator", "Open the calculator app", emptyList(), false),
        ActionDefinition("open_settings", "Open Android system settings", emptyList(), false),
        ActionDefinition("open_camera", "Open the camera app", emptyList(), false),
        ActionDefinition("open_gallery", "Open the photo gallery", emptyList(), false),
        ActionDefinition(
            "shutdown_device",
            "Shut down / turn off / lock the phone. Android only allows locking the screen for non-system apps (not a true power-off) — this is what actually runs.",
            emptyList(),
            true
        ),
        ActionDefinition(
            "remember_fact",
            "Save a short, durable fact about the user for future conversations (name, preferences, routine, people in their life, etc). Never used for one-off/temporary info.",
            listOf("fact"),
            false
        ),
    )

    fun all(): List<ActionDefinition> = definitions

    fun isRegistered(type: String): Boolean = definitions.any { it.type == type }

    fun isSensitive(type: String): Boolean = definitions.firstOrNull { it.type == type }?.isSensitive ?: true

    fun definitionFor(type: String): ActionDefinition? = definitions.firstOrNull { it.type == type }

    /** Renders the registry as compact text for injection into the AI system prompt. */
    fun asPromptCatalog(): String = definitions.joinToString("\n") { def ->
        val params = if (def.parameters.isEmpty()) "no parameters" else "parameters: ${def.parameters.joinToString(", ")}"
        "- ${def.type}: ${def.description} ($params)${if (def.isSensitive) " [SENSITIVE - requires confirmation]" else ""}"
    }
}
