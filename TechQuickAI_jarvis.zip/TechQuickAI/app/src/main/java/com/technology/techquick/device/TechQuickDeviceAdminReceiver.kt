package com.technology.techquick.device

import android.app.admin.DeviceAdminReceiver

/**
 * Required boilerplate receiver so the user can grant TechQuick the
 * "force lock" device-admin policy from Settings. This is what powers the
 * "shut down" / "lock my phone" voice command — see DeviceActions.lockDevice().
 * We request nothing beyond force-lock; TechQuick never wipes data, changes
 * the lock screen password, or otherwise acts as a full MDM policy.
 */
class TechQuickDeviceAdminReceiver : DeviceAdminReceiver()
