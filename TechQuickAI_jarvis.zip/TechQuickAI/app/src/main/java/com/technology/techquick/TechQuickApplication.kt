package com.technology.techquick

import android.app.Application
import com.technology.techquick.actions.ActionEngine
import com.technology.techquick.actions.ActionRegistry
import com.technology.techquick.ai.AIBrain
import com.technology.techquick.data.ConversationRepository
import com.technology.techquick.data.MemoryRepository
import com.technology.techquick.data.PersonalityRepository
import com.technology.techquick.data.SecureStorage
import com.technology.techquick.data.SettingsRepository

/**
 * Application-wide dependency container.
 *
 * TechQuick uses a very small manual DI setup instead of Hilt/Koin so the
 * whole architecture is easy to read end-to-end in one pass. Swap this for
 * Hilt later if the project grows.
 */
class TechQuickApplication : Application() {

    lateinit var secureStorage: SecureStorage
        private set
    lateinit var settingsRepository: SettingsRepository
        private set
    lateinit var conversationRepository: ConversationRepository
        private set
    lateinit var memoryRepository: MemoryRepository
        private set
    lateinit var personalityRepository: PersonalityRepository
        private set
    lateinit var actionRegistry: ActionRegistry
        private set
    lateinit var actionEngine: ActionEngine
        private set
    lateinit var aiBrain: AIBrain
        private set

    override fun onCreate() {
        super.onCreate()

        secureStorage = SecureStorage(this)
        settingsRepository = SettingsRepository(this, secureStorage)
        conversationRepository = ConversationRepository(this)
        memoryRepository = MemoryRepository(this)
        personalityRepository = PersonalityRepository(this)
        actionRegistry = ActionRegistry()
        actionEngine = ActionEngine(this, actionRegistry, memoryRepository)
        aiBrain = AIBrain(settingsRepository, actionRegistry, personalityRepository, memoryRepository)
    }
}
