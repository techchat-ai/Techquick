package com.technology.techquick.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.technology.techquick.TechQuickApplication
import com.technology.techquick.data.MemoryItem
import kotlinx.coroutines.flow.StateFlow

class MemoryViewModel(private val app: TechQuickApplication) : ViewModel() {

    val items: StateFlow<List<MemoryItem>> = app.memoryRepository.items

    fun forget(id: String) = app.memoryRepository.forget(id)
    fun forgetAll() = app.memoryRepository.forgetAll()
    fun rememberManually(fact: String) = app.memoryRepository.remember(fact)

    companion object {
        fun factory(app: TechQuickApplication) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = MemoryViewModel(app) as T
        }
    }
}
