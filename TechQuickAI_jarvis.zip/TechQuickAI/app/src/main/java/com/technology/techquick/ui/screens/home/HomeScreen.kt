package com.technology.techquick.ui.screens.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.technology.techquick.ui.components.AIOrb
import com.technology.techquick.ui.components.InputBar
import com.technology.techquick.ui.components.MessageBubble
import com.technology.techquick.ui.components.OrbState
import com.technology.techquick.ui.components.QuickActionChips
import com.technology.techquick.viewmodel.HomeViewModel
import java.util.Calendar

private fun greeting(): String {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        hour < 12 -> "Good morning"
        hour < 17 -> "Good afternoon"
        else -> "Good evening"
    }
}

private fun orbStatusText(state: OrbState, continuous: Boolean): String = when (state) {
    OrbState.IDLE -> if (continuous) "Jarvis mode on — just speak" else "Tap the mic to talk"
    OrbState.LISTENING -> "Listening..."
    OrbState.THINKING -> "Thinking..."
    OrbState.EXECUTING -> "Working on it..."
    OrbState.FINISHED -> if (continuous) "Listening..." else "Done."
}

/**
 * Jarvis-style HUD: the orb is the permanent centerpiece (not just an empty
 * state), with a Jarvis-mode switch so voice stays live turn after turn
 * instead of needing a mic tap every time. Conversation history collapses
 * into a slim scrollable strip beneath the orb rather than dominating the
 * screen like a chat app.
 */
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onOpenSettings: () -> Unit,
    onNeedsApiKey: () -> Unit
) {
    val state by viewModel.state.collectAsState()
    val listState = rememberLazyListState()

    LaunchedEffect(state.hasApiKey) {
        if (!state.hasApiKey) onNeedsApiKey()
    }
    LaunchedEffect(state.messages.size) {
        if (state.messages.isNotEmpty()) listState.animateScrollToItem(state.messages.size - 1)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Top HUD bar
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    "TECHQUICK",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    "${greeting()}, ${orbStatusText(state.orbState, state.continuousListening)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Filled.AllInclusive,
                    contentDescription = "Jarvis mode",
                    tint = if (state.continuousListening) MaterialTheme.colorScheme.secondary
                    else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                )
                Switch(
                    checked = state.continuousListening,
                    onCheckedChange = { viewModel.setContinuousListening(it) },
                    colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.secondary)
                )
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Filled.Settings, contentDescription = "Settings")
                }
            }
        }

        state.errorBanner?.let { error ->
            Surface(color = MaterialTheme.colorScheme.errorContainer, modifier = Modifier.fillMaxWidth()) {
                Text(error, modifier = Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onErrorContainer)
            }
        }

        // The orb is always the centerpiece — permanent HUD core, not tied to empty state.
        Box(
            modifier = Modifier.fillMaxWidth().height(if (state.messages.isEmpty()) 320.dp else 190.dp),
            contentAlignment = Alignment.Center
        ) {
            AIOrb(state = state.orbState, size = if (state.messages.isEmpty()) 240.dp else 150.dp)
        }

        if (state.messages.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top
            ) {
                Text(
                    "What can I do for you?",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 8.dp)
            ) {
                items(state.messages, key = { it.id }) { message ->
                    MessageBubble(
                        message = message,
                        onConfirm = {
                            message.pendingConfirmation?.let {
                                viewModel.confirmAction(message.id, it.actionType, it.parameters)
                            }
                        },
                        onCancel = { viewModel.cancelAction(message.id) }
                    )
                }
            }
        }

        QuickActionChips(
            onActionSelected = { action -> viewModel.onQuickAction(action.prompt, autoSend = !action.prompt.endsWith(" ") ) },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        )

        InputBar(
            text = state.inputText,
            onTextChange = viewModel::onInputChange,
            onSend = { viewModel.sendMessage() },
            onMicClick = { if (!state.isListening) viewModel.startListening() },
            isListening = state.isListening,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)
        )
    }
}
