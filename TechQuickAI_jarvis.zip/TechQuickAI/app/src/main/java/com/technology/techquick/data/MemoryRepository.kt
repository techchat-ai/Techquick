package com.technology.techquick.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class MemoryItem(
    val id: String = UUID.randomUUID().toString(),
    val fact: String,
    val savedAt: Long = System.currentTimeMillis()
)

/**
 * What TechQuick has learned and remembered about the user — the backing
 * store for the "What TechQuick remembers about you" screen. The AI brain
 * writes to this via the non-sensitive `remember_fact` action whenever the
 * user mentions something durable (name, preferences, routine, people in
 * their life, etc). Nothing here is sent anywhere except back into future
 * system prompts, so the assistant can recall it naturally.
 */
class MemoryRepository(context: Context) {

    private val prefs = context.getSharedPreferences("techquick_memory", Context.MODE_PRIVATE)

    private val _items = MutableStateFlow(load())
    val items: StateFlow<List<MemoryItem>> = _items

    private fun load(): List<MemoryItem> {
        val raw = prefs.getString(KEY_ITEMS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                MemoryItem(o.getString("id"), o.getString("fact"), o.optLong("savedAt", System.currentTimeMillis()))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun persist(items: List<MemoryItem>) {
        val arr = JSONArray()
        items.forEach { item ->
            arr.put(JSONObject().apply {
                put("id", item.id); put("fact", item.fact); put("savedAt", item.savedAt)
            })
        }
        prefs.edit().putString(KEY_ITEMS, arr.toString()).apply()
    }

    /** Adds a fact if it isn't already substantially remembered (simple de-dupe). */
    fun remember(fact: String) {
        val cleaned = fact.trim()
        if (cleaned.isBlank()) return
        val current = _items.value
        if (current.any { it.fact.equals(cleaned, ignoreCase = true) }) return
        val updated = current + MemoryItem(fact = cleaned)
        _items.value = updated
        persist(updated)
    }

    fun forget(id: String) {
        val updated = _items.value.filterNot { it.id == id }
        _items.value = updated
        persist(updated)
    }

    fun forgetAll() {
        _items.value = emptyList()
        persist(emptyList())
    }

    /** Compact text form injected into the AI system prompt. */
    fun asPromptContext(): String =
        if (_items.value.isEmpty()) "(nothing saved yet)"
        else _items.value.joinToString("\n") { "- ${it.fact}" }

    private companion object {
        const val KEY_ITEMS = "items"
    }
}
