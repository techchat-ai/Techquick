package com.technology.techquick.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class AssistantMood(val displayName: String, val promptDescription: String) {
    FRIENDLY("Friendly", "warm, casual, encouraging — like a good friend who's great with tech"),
    FORMAL("Formal", "polished, respectful, professional — minimal small talk"),
    WITTY("Witty", "sharp, a little playful and humorous, but never annoying or childish"),
    DIRECT("Direct", "brief and to the point, no fluff, just the answer/action"),
    CALM("Calm", "measured, reassuring, unhurried — a steady presence")
}

/**
 * User-controlled "who is TechQuick" settings: mood/tone plus free-form
 * custom instructions (e.g. "call me Boss", "always reply in Hinglish").
 * Injected straight into AIBrain's system prompt every turn.
 */
class PersonalityRepository(context: Context) {

    private val prefs = context.getSharedPreferences("techquick_personality", Context.MODE_PRIVATE)

    private val _mood = MutableStateFlow(loadMood())
    val mood: StateFlow<AssistantMood> = _mood

    private val _customInstructions = MutableStateFlow(prefs.getString(KEY_CUSTOM, "").orEmpty())
    val customInstructions: StateFlow<String> = _customInstructions

    private val _assistantName = MutableStateFlow(prefs.getString(KEY_NAME, "TechQuick").orEmpty())
    val assistantName: StateFlow<String> = _assistantName

    private fun loadMood(): AssistantMood =
        AssistantMood.entries.firstOrNull { it.name == prefs.getString(KEY_MOOD, AssistantMood.FRIENDLY.name) }
            ?: AssistantMood.FRIENDLY

    fun setMood(mood: AssistantMood) {
        prefs.edit().putString(KEY_MOOD, mood.name).apply()
        _mood.value = mood
    }

    fun setCustomInstructions(text: String) {
        prefs.edit().putString(KEY_CUSTOM, text).apply()
        _customInstructions.value = text
    }

    fun setAssistantName(name: String) {
        val clean = name.ifBlank { "TechQuick" }
        prefs.edit().putString(KEY_NAME, clean).apply()
        _assistantName.value = clean
    }

    fun asPromptContext(): String = buildString {
        append("Assistant name (what the user calls you): ${_assistantName.value}\n")
        append("Mood/personality: ${_mood.value.promptDescription}\n")
        if (_customInstructions.value.isNotBlank()) {
            append("Extra instructions from the user about how to behave: ${_customInstructions.value}")
        }
    }

    private companion object {
        const val KEY_MOOD = "mood"
        const val KEY_CUSTOM = "custom_instructions"
        const val KEY_NAME = "assistant_name"
    }
}
